//
// This source file is part of the Swift.org open source project
//
// Copyright (c) 2024–2025 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
// See https://swift.org/CONTRIBUTORS.txt for Swift project authors
//

#if SWT_TARGET_OS_APPLE && canImport(CoreImage)
public import CoreImage
public import _Testing_CoreGraphics

/// @Metadata {
///   @Available(Swift, introduced: 6.3)
///   @Available(Xcode, introduced: 26.4)
/// }
@available(_uttypesAPI, *)
extension CIImage: AttachableAsImage, AttachableAsCGImage {
  /// @Metadata {
  ///   @Available(Swift, introduced: 6.3)
  ///   @Available(Xcode, introduced: 26.4)
  /// }
  package var attachableCGImage: CGImage {
    get throws {
      guard let result = CIContext().createCGImage(self, from: extent) else {
        throw ImageAttachmentError.couldNotCreateCGImage
      }
      return result
    }
  }

  public func withUnsafeBytes<R>(as imageFormat: AttachableImageFormat, _ body: (UnsafeRawBufferPointer) throws -> R) throws -> R {
    try withUnsafeBytesImpl(as: imageFormat, body)
  }

  public func _copyAttachableValue() -> Self {
    // CIImage is documented as thread-safe, but does not conform to Sendable.
    // It conforms to NSCopying but does not actually copy itself, so there's no
    // point in calling copy().
    self
  }
}
#endif
