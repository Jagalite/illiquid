#!/usr/bin/env python3
"""Independently audit the frozen, six-pair NaturalFilenameSortStorage study.

Reads evidence only. It never imports the benchmark runner, runs a measured
program, builds sources, or modifies the evidence directory. JSON is emitted to
stdout; a failed check gives a nonzero exit status.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import sys


BASELINE = "ea2ff568237e2667f7b1aeee67b11a44ebe95b72"
PAIRS = 6
VARIANTS = ("baseline", "candidate")
MODES = ("latency", "allocations")
OPERATIONS = ("urls", "playlist")
PATTERNS = ("shuffled", "sorted", "reversed", "ties", "unicode")
SIZES = (1000, 10000)
CONTROLS = (0, 1, 2, 3, 8)
SOURCES = (
    "Sources/IlliquidCore/Utilities/NaturalFilenameOrdering.swift",
    "Sources/IlliquidCore/Playlist/FolderPlaylist.swift",
    "Sources/IlliquidCore/Utilities/NormalizedFileURL.swift",
)
TESTS = (
    "Tests/IlliquidCoreTests/NaturalFilenameOrderingTests.swift",
    "Tests/IlliquidCoreTests/FolderPlaylistTests.swift",
)
DRIVERS = ("run.py", "Harness.swift", "allocmeter.c", "MeterCheck.c")
METRICS = {
    "latency": ("ns_per_iteration",),
    "allocations": (
        "allocation_requested_bytes", "allocation_requests", "allocation_max_request"
    ),
}
METADATA = {"case", "variant", "pair", "order"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class AuditStop(Exception):
    pass


class Audit:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.checks = 0
        self.failures: list[str] = []
        self.files: dict[str, str] = {}
        self.counts: dict[str, object] = {}

    def check(self, condition: bool, message: str, *, required: bool = False) -> None:
        self.checks += 1
        if not condition:
            self.failures.append(message)
            if required:
                raise AuditStop(message)

    def path(self, relative: str) -> Path:
        path = (self.root / relative).resolve()
        self.check(path.is_relative_to(self.root), f"Path escapes evidence: {relative}", required=True)
        self.check(path.is_file(), f"Missing evidence file: {relative}", required=True)
        return path

    def data(self, relative: str, expected_hash: str | None = None) -> bytes:
        data = self.path(relative).read_bytes()
        actual_hash = sha256(data)
        if relative in self.files:
            self.check(self.files[relative] == actual_hash,
                       f"Evidence changed during audit: {relative}")
        self.files[relative] = actual_hash
        if expected_hash is not None:
            self.check(actual_hash == expected_hash, f"SHA-256 mismatch: {relative}")
        return data

    def json(self, relative: str):
        return json.loads(self.data(relative))

    def jsonl(self, relative: str) -> list:
        text = self.data(relative).decode()
        self.check(text.endswith("\n"), f"Missing final JSONL newline: {relative}")
        lines = text.splitlines()
        self.check(all(lines), f"Blank JSONL row: {relative}")
        return [json.loads(line) for line in lines]

    def equal(self, actual, expected, label: str) -> None:
        """Exact structural comparisons; allow only normal float-rounding noise."""
        if isinstance(expected, dict):
            self.check(isinstance(actual, dict), f"Expected object: {label}", required=True)
            self.check(set(actual) == set(expected), f"Object keys differ: {label}")
            for key in expected:
                self.check(key in actual, f"Missing key: {label}/{key}", required=True)
                self.equal(actual[key], expected[key], f"{label}/{key}")
        elif isinstance(expected, list):
            self.check(isinstance(actual, list), f"Expected list: {label}", required=True)
            self.check(len(actual) == len(expected), f"List length differs: {label}")
            for index, (left, right) in enumerate(zip(actual, expected)):
                self.equal(left, right, f"{label}/{index}")
        elif isinstance(expected, (int, float)) and not isinstance(expected, bool):
            numeric = isinstance(actual, (int, float)) and not isinstance(actual, bool)
            self.check(numeric and math.isfinite(actual)
                       and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-9),
                       f"Numeric mismatch: {label}: {actual!r} != {expected!r}")
        else:
            self.check(type(actual) is type(expected) and actual == expected,
                       f"Value mismatch: {label}: {actual!r} != {expected!r}")


def distribution(values: list):
    if not values:
        return None
    ordered = sorted(values)
    middle = len(ordered) // 2
    median = ordered[middle] if len(ordered) % 2 else (ordered[middle - 1] + ordered[middle]) / 2
    return {"median": median, "min": ordered[0], "max": ordered[-1]}


def paired_change(before, after):
    if before == 0:
        return 0.0 if after == 0 else None
    return (after / before - 1.0) * 100.0


def run_audit(audit: Audit) -> None:
    root = audit.root
    manifest = audit.json("manifest.json")
    cases = audit.json("cases.json")
    rows = audit.jsonl("observations.jsonl")
    commands = audit.jsonl("commands.jsonl")
    verification = audit.json("verification.json")
    summary = audit.json("summary.json")
    audit.check("error" not in manifest, "Manifest reports a study error")
    audit.check(manifest["baseline"] == BASELINE, "Wrong pinned baseline")
    audit.check(manifest["head"] == BASELINE, "Unexpected worktree HEAD for this frozen cohort")
    audit.check(manifest["host"]["system"] == "Linux"
                and manifest["host"]["libc"][0] == "glibc", "This audit expects the Linux/glibc cohort")
    options = manifest["options"]
    audit.check(options["pairs"] == PAIRS and options["resolved_sizes"] == list(SIZES)
                and options["quick"] is False and options["skip_tests"] is False
                and options["tests_only"] is False and not options.get("current_support", False),
                "Study options do not describe the frozen full six-pair cohort")

    by_label = defaultdict(list)
    log_paths = []
    for command in commands:
        by_label[command["label"]].append(command)
        audit.check(command["returncode"] == 0 and command["timed_out"] is False,
                    f"Failed/timed-out command: {command['label']}")
        for key in ("stdout", "stderr"):
            audit.data(command[key])
            log_paths.append(command[key])
    audit.check(len(log_paths) == len(set(log_paths)), "Command logs are reused")

    def command(label: str) -> dict:
        matches = by_label[label]
        audit.check(len(matches) == 1, f"Expected exactly one command: {label}", required=True)
        return matches[0]

    def command_text(label: str) -> str:
        record = command(label)
        return audit.data(record["stdout"]).decode() + "\n" + audit.data(record["stderr"]).decode()

    expected_tests = [("baseline", "release"), ("candidate", "debug"), ("candidate", "release")]
    expected_test_manifest = [{"variant": variant, "configuration": config, "passed": True}
                              for variant, config in expected_tests]
    audit.equal(manifest["tests_run"], expected_test_manifest, "manifest/tests_run")
    for variant, config in expected_tests:
        text = command_text(f"test-{variant}-{config}")
        matches = re.findall(r"Test run with (\d+) tests? in (\d+) suites? passed after", text)
        audit.check(matches == [("13", "2")], f"Missing 13-test/2-suite success: {variant}/{config}")
        audit.check(not re.search(r"Test run with \d+ tests?.*failed", text),
                    f"Swift Testing failure in {variant}/{config}")
    audit.check("Allocation meter calibration passed:" in command_text("meter-check"),
                "Missing allocation-meter calibration success")
    audit.check(set(verification) == set(VARIANTS), "Verification variants differ", required=True)
    audit.equal(verification["candidate"], verification["baseline"], "verification parity")
    for variant in VARIANTS:
        result = verification[variant]
        audit.check(result["checks"] == 66 and result["full_output_verified"] is True,
                    f"Incomplete verification: {variant}")
        audit.equal(json.loads(audit.data(command(f"verify-{variant}")["stdout"])), result,
                    f"verification stdout/{variant}")

    for variant in VARIANTS:
        audit.check(set(manifest["sources"][variant]) == set(SOURCES), f"Unexpected sources: {variant}")
        for source in SOURCES:
            staged = f"{variant}/Sources/IlliquidCore/{Path(source).name}"
            data = audit.data(staged, manifest["sources"][variant][source])
            if variant == "baseline":
                record = command("baseline-" + Path(source).stem)
                audit.check(record["command"] == ["git", "show", f"{BASELINE}:{source}"],
                            f"Baseline command source mismatch: {source}")
                audit.check(audit.data(record["stdout"]) == data,
                            f"Baseline staged bytes differ from git-show receipt: {source}")
        for test in TESTS:
            audit.data(f"{variant}/Tests/IlliquidCoreTests/{Path(test).name}", manifest["tests"][test])
    audit.check(set(manifest["tests"]) == set(TESTS), "Unexpected test inventory")
    for source in SOURCES[1:]:
        audit.check(manifest["sources"]["baseline"][source] == manifest["sources"]["candidate"][source],
                    f"Unchanged support differs: {source}")
    audit.check(manifest["sources"]["baseline"][SOURCES[0]] != manifest["sources"]["candidate"][SOURCES[0]],
                "Measured baseline and candidate sorter are identical")
    audit.check(audit.data("baseline/Package.swift") == audit.data("candidate/Package.swift"),
                "Baseline/candidate test package manifests differ")
    audit.check(set(manifest["drivers"]) == set(DRIVERS), "Unexpected driver inventory")
    for name in DRIVERS:
        audit.data("drivers/" + name, manifest["drivers"][name])
    for path, expected in manifest["binaries"].items():
        audit.data(path, expected)
    for variant in VARIANTS:
        for name in ("latency", "allocations", "libIlliquidCore.so", "IlliquidCore.swiftmodule"):
            audit.check(f"{variant}/bin/{name}" in manifest["binaries"],
                        f"Required measured binary is missing: {variant}/{name}")
        module_build = command(f"build-{variant}-module")["command"]
        for source in SOURCES:
            audit.check(str(root / variant / "Sources/IlliquidCore" / Path(source).name) in module_build,
                        f"Module build does not use staged source: {variant}/{source}")
        for flag in ("-whole-module-optimization", "-emit-library", "-emit-module", "-O"):
            audit.check(flag in module_build, f"Missing module build flag: {variant}/{flag}")
        for mode in MODES:
            build = command(f"build-{variant}-{mode}")["command"]
            audit.check(str(root / "drivers/Harness.swift") in build
                        and not any(str(root / variant / "Sources/IlliquidCore" / Path(s).name) in build for s in SOURCES),
                        f"Driver is not built separately from production: {variant}/{mode}")
            audit.check(("-lallocmeter" in build) == (mode == "allocations"),
                        f"Meter link isolation failed: {variant}/{mode}")
    audit.check("drivers/liballocmeter.so" in manifest["binaries"]
                and "drivers/meter-check" in manifest["binaries"], "Missing meter binary hashes")

    expected_cases = {(operation, pattern, count) for operation in OPERATIONS
                      for pattern in PATTERNS for count in SIZES}
    expected_cases |= {(operation, "shuffled", count) for operation in OPERATIONS for count in CONTROLS}
    actual_cases = {(c["operation"], c["pattern"], c["count"]) for c in cases}
    audit.check(len(cases) == 30 and actual_cases == expected_cases, "Wrong or duplicated case inventory")
    by_case = {case["id"]: case for case in cases}
    audit.check(len(by_case) == 30, "Duplicate case IDs")
    for case in cases:
        audit.check(case["id"] == f"{case['operation']}/{case['pattern']}/{case['count']}",
                    f"Malformed case ID: {case['id']}")
        expected_iterations = min(1000, max(1, 10000 // max(1, case["count"])))
        audit.check(case["iterations"] == expected_iterations, f"Wrong iteration count: {case['id']}")
    audit.check(len(rows) == 720, f"Expected 720 persisted observations, found {len(rows)}")
    measurements = [c for c in commands if re.fullmatch(r"(latency|allocations)-(baseline|candidate)-\d+", c["label"])]
    audit.check(len(measurements) == 720, "Expected 720 measurement command receipts")
    keyed = {}
    cohorts = defaultdict(list)
    for index, row in enumerate(rows):
        case_id, mode, pair, variant = row["case"], row["mode"], row["pair"], row["variant"]
        key = (case_id, mode, pair, variant)
        audit.check(key not in keyed, f"Duplicate observation key: {key}")
        keyed[key] = row
        audit.check(case_id in by_case and mode in MODES and variant in VARIANTS
                    and type(pair) is int and 0 <= pair < PAIRS, f"Unexpected row identity: {key}", required=True)
        case = by_case[case_id]
        iterations = 1 if mode == "allocations" else case["iterations"]
        audit.check(row["operation"] == case["operation"] and row["pattern"] == case["pattern"]
                    and row["count"] == case["count"] and row["iterations"] == iterations
                    and row["warmup_iterations"] == 2 and row["full_output_verified"] is True,
                    f"Case/iteration/verification mismatch: {key}")
        expected_order = ["baseline", "candidate"] if pair % 2 == 0 else ["candidate", "baseline"]
        audit.check(row["order"] == expected_order, f"Wrong AB/BA order: {key}")
        record = command(f"{mode}-{variant}-{index:04d}")
        raw = json.loads(audit.data(record["stdout"]))
        audit.check(raw == {k: v for k, v in row.items() if k not in METADATA},
                    f"Observation differs from corresponding command stdout: {key}")
        arguments = (["--allocations"] if mode == "allocations" else [])
        arguments += [case["operation"], case["pattern"], str(case["count"]), str(iterations)]
        audit.check(record["command"] == [str(root / variant / "bin" / mode), *arguments],
                    f"Measured command differs from requested case: {key}")
        expected_environment = {"LD_PRELOAD": str(root / "drivers/liballocmeter.so")} if mode == "allocations" else {}
        audit.check(record["environment_overrides"] == expected_environment, f"Meter preload isolation failed: {key}")
        audit.check(row["layout"] == verification[variant]["layout"]
                    and row["locale"] == verification[variant]["locale"], f"Layout/locale drift: {key}")
        audit.equal(row["ns_per_iteration"], row["elapsed_ns"] / iterations, f"elapsed division/{key}")
        if mode == "allocations":
            largest = row["large_allocations"]
            audit.check(len(largest) <= 16 and all(item["requests"] > 0 and item["bytes"] >= 0 for item in largest),
                        f"Invalid large-allocation histogram: {key}")
            sizes = [item["bytes"] for item in largest]
            audit.check(sizes == sorted(set(sizes), reverse=True), f"Histogram order/uniqueness: {key}")
            audit.check(sum(item["requests"] for item in largest) <= row["allocation_requests"]
                        and sum(item["requests"] * item["bytes"] for item in largest) <= row["allocation_requested_bytes"],
                        f"Histogram exceeds cumulative counts: {key}")
            audit.check(row["allocation_max_request"] == (sizes[0] if sizes else 0),
                        f"Histogram maximum mismatch: {key}")
        cohorts[(case_id, mode)].append(row)

    expected_keys = {(case_id, mode, pair, variant) for case_id in by_case for mode in MODES
                     for pair in range(PAIRS) for variant in VARIANTS}
    audit.check(set(keyed) == expected_keys, "Missing or unexpected observation keys", required=True)
    audit.check([command["label"] for command in measurements]
                == [f"{row['mode']}-{row['variant']}-{index:04d}" for index, row in enumerate(rows)],
                "Measurement receipts do not follow persisted observation order")
    for case_id in by_case:
        all_rows = [keyed[(case_id, mode, pair, variant)] for mode in MODES
                    for pair in range(PAIRS) for variant in VARIANTS]
        for field in ("fingerprint", "locale", "warmup_checksum"):
            audit.check(len({row[field] for row in all_rows}) == 1, f"Cross-mode/variant drift: {case_id}/{field}")
        for mode in MODES:
            group = cohorts[(case_id, mode)]
            audit.check(len(group) == 12 and len({row["checksum"] for row in group}) == 1,
                        f"Checksum or replicate mismatch: {case_id}/{mode}")
            orders = Counter(tuple(keyed[(case_id, mode, pair, "baseline")]["order"]) for pair in range(PAIRS))
            audit.check(orders == {("baseline", "candidate"): 3, ("candidate", "baseline"): 3},
                        f"Unbalanced paired order: {case_id}/{mode}")
            for pair in range(PAIRS):
                left, right = [keyed[(case_id, mode, pair, variant)] for variant in VARIANTS]
                for field in ("operation", "pattern", "count", "iterations", "locale", "checksum",
                              "fingerprint", "full_output_verified", "layout", "warmup_checksum"):
                    audit.check(left[field] == right[field], f"Paired identity differs: {case_id}/{mode}/{pair}/{field}")
        if by_case[case_id]["iterations"] == 1:
            audit.check(len({row["checksum"] for row in all_rows}) == 1, f"One-iteration cross-mode checksum mismatch: {case_id}")

    reconstructed = []
    for case in cases:
        metrics = {}
        for mode in MODES:
            for metric in METRICS[mode]:
                before = [keyed[(case["id"], mode, pair, "baseline")][metric] for pair in range(PAIRS)]
                after = [keyed[(case["id"], mode, pair, "candidate")][metric] for pair in range(PAIRS)]
                changes = [paired_change(left, right) for left, right in zip(before, after)]
                metrics[metric] = {"baseline": distribution(before), "candidate": distribution(after),
                                   "paired_percent_change": distribution([value for value in changes if value is not None])}
        reconstructed.append({**case, "metrics": metrics})
    audit.equal(summary["cases"], reconstructed, "summary/cases")
    categories = {}
    for operation in OPERATIONS:
        categories[operation] = {}
        for metric in [metric for metrics in METRICS.values() for metric in metrics]:
            values = [case["metrics"][metric]["paired_percent_change"]["median"] for case in reconstructed
                      if case["operation"] == operation and case["metrics"][metric]["paired_percent_change"] is not None]
            categories[operation][metric] = distribution(values)
    audit.equal(summary["categories"], categories, "summary/categories")
    audit.check(summary["pairs"] == PAIRS and summary["tests_skipped"] is False,
                "Summary pair/test metadata differs")
    audit.check(summary["category_statistic"] == "distribution of case median paired percentage changes",
                "Category statistic is mislabeled")
    audit.equal(summary["notes"], manifest["notes"], "summary/notes")
    audit.counts = {
        "commands": len(commands), "measurement_commands": len(measurements),
        "cases": len(cases), "observations": len(rows), "unique_observation_keys": len(keyed),
        "modes": dict(Counter(row["mode"] for row in rows)),
        "paired_comparisons": len(cases) * len(MODES) * PAIRS,
        "balanced_case_mode_groups": len(cohorts), "AB_pairs": 180, "BA_pairs": 180,
        "tests_per_configuration": 13, "test_configurations": 3,
        "verification_cases_per_variant": 66,
        "case_metric_summaries_recomputed": len(cases) * 4,
        "category_distributions_recomputed": 8,
        "source_snapshots": len(SOURCES) * 2, "test_snapshots": len(TESTS) * 2,
        "driver_snapshots": len(DRIVERS), "binary_hashes": len(manifest["binaries"]),
    }
    # Re-read accepted aggregate files at the end so a changing run cannot pass.
    for name in ("manifest.json", "cases.json", "observations.jsonl", "commands.jsonl", "verification.json", "summary.json"):
        audit.data(name)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence", type=Path)
    args = parser.parse_args()
    audit = Audit(args.evidence)
    error = None
    try:
        run_audit(audit)
    except Exception as exception:
        error = f"{type(exception).__name__}: {exception}"
        if not isinstance(exception, AuditStop):
            audit.failures.append(error)
    script = Path(__file__).resolve()
    report = {
        "schema": "natural-filename-sort-storage-independent-audit-v1",
        "audited_at_utc": datetime.now(timezone.utc).isoformat(),
        "evidence_directory": str(audit.root),
        "auditor": {"path": str(script), "sha256": sha256(script.read_bytes()),
                    "python": sys.version.split()[0]},
        "passed": not audit.failures and error is None,
        "checks": audit.checks, "counts": audit.counts,
        "failures": audit.failures, "error": error,
        "file_sha256": dict(sorted(audit.files.items())),
        "scope": [
            "Read-only verification of the frozen Linux/glibc cohort, not a measurement rerun.",
            "No benchmark-runner import; summaries are reconstructed independently from persisted observations.",
            "Fingerprints and warmup checksums match across modes; timed checksums match across variants/repeats within each mode.",
            "Cross-mode timed checksums are compared only when latency and allocation both execute one iteration.",
            "Allocation-request accounting is cumulative traffic, not retained heap, peak RSS, or macOS footprint.",
        ],
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
