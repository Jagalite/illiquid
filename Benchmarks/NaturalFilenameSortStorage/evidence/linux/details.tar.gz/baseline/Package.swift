// swift-tools-version: 6.1
import PackageDescription
let package = Package(name: "NaturalFilenameSortStorageProbe", targets: [
    .target(name: "IlliquidCore"),
    .testTarget(name: "IlliquidCoreTests", dependencies: ["IlliquidCore"]),
])
