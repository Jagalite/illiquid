from pathlib import Path
import subprocess, json, os, hashlib, statistics, time
root=Path(__file__).resolve().parent
original=root.parent/'sort-full'
compiler='/workspace/scratch/663a3fdba62e/swift-toolchain/usr/bin/swiftc'
manifest={'reason':'Resolve slower timing cases in the full allocation study; retain all original results', 'pairs':12,'affinity':sorted(os.sched_getaffinity(0)),'harness_sha256':hashlib.sha256((root/'Harness.swift').read_bytes()).hexdigest(),'source_cohort_manifest_sha256':hashlib.sha256((original/'manifest.json').read_bytes()).hexdigest(),'binaries':{},'cases':[('playlist','shuffled',10000,4),('urls','shuffled',1000,40),('urls','ties',1000,20)]}
for variant in ('baseline','candidate'):
    lib=original/variant/'bin'
    command=[compiler,'-O','-parse-as-library','-swift-version','6','-warnings-as-errors','-module-cache-path',str(original/'module-cache'),'-I',str(lib),'-L',str(lib),'-lIlliquidCore','-Xlinker','-rpath','-Xlinker',str(lib),str(root/'Harness.swift'),'-o',str(root/variant)]
    r=subprocess.run(command,capture_output=True,text=True)
    (root/f'build-{variant}.json').write_text(json.dumps({'command':command,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2)+'\n')
    r.check_returncode()
    manifest['binaries'][variant]=hashlib.sha256((root/variant).read_bytes()).hexdigest()
    manifest['binaries'][variant+'_library']=hashlib.sha256((lib/'libIlliquidCore.so').read_bytes()).hexdigest()
cpu=min(os.sched_getaffinity(0));os.sched_setaffinity(0,{cpu});manifest['measurement_cpu']=cpu
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
rows=[]
for op,pattern,count,iterations in manifest['cases']:
    case=f'{op}/{pattern}/{count}'
    print('Measuring targeted follow-up',case,flush=True)
    for pair in range(12):
        order=['baseline','candidate'] if pair%2==0 else ['candidate','baseline']
        outputs={}
        for variant in order:
            cmd=[str(root/variant),op,pattern,str(count),str(iterations)]
            r=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
            with (root/'commands.jsonl').open('a') as f:f.write(json.dumps({'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})+'\n')
            r.check_returncode();v=json.loads(r.stdout);outputs[variant]=v
            v.update(variant=variant,pair=pair,order=order,case=case);rows.append(v)
            with (root/'observations.jsonl').open('a') as f:f.write(json.dumps(v,sort_keys=True)+'\n')
        assert all(outputs['baseline'][k]==outputs['candidate'][k] for k in ['fingerprint','checksum','full_output_verified','count','iterations','locale'])
summary=[]
for op,pattern,count,_ in manifest['cases']:
    case=f'{op}/{pattern}/{count}';record={'case':case,'metrics':{}}
    for metric in ['ns_per_iteration','cpu_ns_per_iteration']:
        a=[r[metric] for r in rows if r['case']==case and r['variant']=='baseline'];b=[r[metric] for r in rows if r['case']==case and r['variant']=='candidate']
        record['metrics'][metric]={'baseline_median':statistics.median(a),'candidate_median':statistics.median(b),'paired_change_median_pct':statistics.median([100*(y/x-1) for x,y in zip(a,b)]),'baseline_range':[min(a),max(a)],'candidate_range':[min(b),max(b)]}
    summary.append(record)
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
