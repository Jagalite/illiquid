#!/usr/bin/env python3
"""Read-only audit of the targeted sort latency/CPU follow-up; never rerun it."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys


CASES = (("playlist", "shuffled", 10000, 4), ("urls", "shuffled", 1000, 40), ("urls", "ties", 1000, 20))
PAIRS = 12
VARIANTS = ("baseline", "candidate")
METRICS = ("ns_per_iteration", "cpu_ns_per_iteration")
METADATA = {"variant", "pair", "order", "case"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def median(values):
    values = sorted(values)
    middle = len(values) // 2
    return values[middle] if len(values) % 2 else (values[middle - 1] + values[middle]) / 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("followup", type=Path)
    parser.add_argument("original", type=Path)
    args = parser.parse_args()
    followup, original = args.followup.resolve(), args.original.resolve()
    failures, hashes = [], {}
    checks = 0
    counts, rebuilt = {}, []

    def check(condition, message):
        nonlocal checks
        checks += 1
        if not condition:
            failures.append(message)

    def data(path, expected=None):
        path = path.resolve()
        content = path.read_bytes()
        value = digest(content)
        if str(path) in hashes:
            check(hashes[str(path)] == value, f"Evidence changed during audit: {path}")
        hashes[str(path)] = value
        if expected is not None:
            check(value == expected, f"SHA-256 differs: {path}")
        return content

    def load(path):
        return json.loads(data(path))

    def jsonl(path):
        text = data(path).decode()
        check(text.endswith("\n") and all(text.splitlines()), f"Incomplete/blank JSONL: {path}")
        return [json.loads(line) for line in text.splitlines()]

    def equal(left, right, label):
        if isinstance(right, dict):
            check(isinstance(left, dict) and set(left) == set(right), f"Object differs: {label}")
            for key in right:
                equal(left[key], right[key], label + "/" + key)
        elif isinstance(right, list):
            check(isinstance(left, list) and len(left) == len(right), f"List differs: {label}")
            for index, (a, b) in enumerate(zip(left, right)):
                equal(a, b, f"{label}/{index}")
        elif isinstance(right, (int, float)) and not isinstance(right, bool):
            check(isinstance(left, (int, float)) and math.isfinite(left)
                  and math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-9), f"Number differs: {label}: {left} != {right}")
        else:
            check(type(left) is type(right) and left == right, f"Value differs: {label}")

    error = None
    try:
        manifest = load(followup / "manifest.json")
        summary = load(followup / "summary.json")
        observations = jsonl(followup / "observations.jsonl")
        commands = jsonl(followup / "commands.jsonl")
        main_manifest_bytes = data(original / "manifest.json", manifest["source_cohort_manifest_sha256"])
        main_manifest = json.loads(main_manifest_bytes)
        main_observations = jsonl(original / "observations.jsonl")
        check(manifest["pairs"] == PAIRS and manifest["cases"] == [list(case) for case in CASES], "Unexpected follow-up design")
        check(manifest["measurement_cpu"] in manifest["affinity"], "Selected CPU was not permitted by recorded affinity")
        driver = data(followup / "run.py").decode()
        check("os.sched_setaffinity(0,{cpu})" in driver
              and driver.index("os.sched_setaffinity(0,{cpu})") < driver.index("for op,pattern,count,iterations in manifest['cases']"),
              "Driver does not pin affinity before child measurements")
        check("cpu=min(os.sched_getaffinity(0))" in driver
              and manifest["measurement_cpu"] == min(manifest["affinity"]), "Selected CPU does not match driver selection")
        harness = data(followup / "Harness.swift", manifest["harness_sha256"]).decode()
        original_harness = data(original / "drivers/Harness.swift", main_manifest["drivers"]["Harness.swift"]).decode()
        additions = [
            "#if os(Linux)\nimport Glibc\n#else\nimport Darwin\n#endif\n",
            "        let cpuStart = clock()\n",
            "        let cpuNanoseconds = Double(clock() - cpuStart) * 1_000_000_000 / Double(CLOCKS_PER_SEC)\n",
            '            "cpu_ns_per_iteration": cpuNanoseconds / Double(iterations),\n',
        ]
        stripped_harness = harness
        for addition in additions:
            check(stripped_harness.count(addition) == 1, "Unexpected/missing CPU-timer harness addition")
            stripped_harness = stripped_harness.replace(addition, "")
        check(stripped_harness == original_harness, "Follow-up changes more than CPU timing in harness")
        for variant in VARIANTS:
            data(followup / variant, manifest["binaries"][variant])
            library = original / variant / "bin/libIlliquidCore.so"
            library_hash = digest(data(library, manifest["binaries"][variant + "_library"]))
            check(library_hash == main_manifest["binaries"][f"{variant}/bin/libIlliquidCore.so"], f"Library differs from main cohort: {variant}")
            build = load(followup / f"build-{variant}.json")
            check(build["returncode"] == 0, f"Follow-up harness build failed: {variant}")
            expected_command = [main_manifest["swiftc"], "-O", "-parse-as-library", "-swift-version", "6", "-warnings-as-errors",
                                "-module-cache-path", str(original / "module-cache"),
                                "-I", str(original / variant / "bin"), "-L", str(original / variant / "bin"),
                                "-lIlliquidCore", "-Xlinker", "-rpath", "-Xlinker", str(original / variant / "bin"),
                                str(followup / "Harness.swift"), "-o", str(followup / variant)]
            check(build["command"] == expected_command, f"Build does not link exact original library/module: {variant}")
            check("-lallocmeter" not in build["command"] and "ALLOCATION_METER" not in build["command"], f"Meter is linked into latency follow-up: {variant}")

        check(len(observations) == 72 and len(commands) == 72, "Expected 72 observations and command receipts")
        keyed = {}
        duration_ms = []
        original_by_case = defaultdict(list)
        for row in main_observations:
            original_by_case[row["case"]].append(row)
        for index, (row, command) in enumerate(zip(observations, commands)):
            case, pair, variant = row["case"], row["pair"], row["variant"]
            key = (case, pair, variant)
            check(key not in keyed, f"Duplicate follow-up identity: {key}")
            keyed[key] = row
            check(command["returncode"] == 0, f"Measurement command failed: {index}")
            check(json.loads(command["stdout"]) == {k: v for k, v in row.items() if k not in METADATA},
                  f"Observation differs from command stdout: {index}")
            check(command["command"] == [str(followup / variant), row["operation"], row["pattern"], str(row["count"]), str(row["iterations"])],
                  f"Measured command differs from row: {index}")
            check(case == f"{row['operation']}/{row['pattern']}/{row['count']}", f"Malformed case ID: {index}")
            check(type(pair) is int and 0 <= pair < PAIRS and variant in VARIANTS, f"Invalid pair/variant: {index}")
            check(row["mode"] == "latency" and row["full_output_verified"] is True and row["warmup_iterations"] == 2,
                  f"Incomplete verification/mode: {index}")
            check(row["order"] == (["baseline", "candidate"] if pair % 2 == 0 else ["candidate", "baseline"]), f"Wrong AB/BA order: {index}")
            for metric in METRICS:
                check(isinstance(row[metric], (int, float)) and math.isfinite(row[metric]) and row[metric] > 0,
                      f"Invalid latency/CPU metric: {index}/{metric}")
            equal(row["ns_per_iteration"], row["elapsed_ns"] / row["iterations"], f"Wall-time division/{index}")
            duration_ms.append(row["elapsed_ns"] / 1e6)
            check(bool(original_by_case[case]), f"Case absent from main cohort: {case}")
            for prior in original_by_case[case]:
                for field in ("fingerprint", "locale", "layout", "warmup_checksum"):
                    check(row[field] == prior[field], f"Follow-up/main semantic identity differs: {index}/{field}")
            # Timed checksums intentionally differ from the main cohort because
            # the longer loops sample more output positions. Compare within this
            # cohort; full-output fingerprints above compare across cohorts.

        expected_keys = {(f"{op}/{pattern}/{count}", pair, variant) for op, pattern, count, _ in CASES
                         for pair in range(PAIRS) for variant in VARIANTS}
        check(set(keyed) == expected_keys and len(keyed) == 72, "Missing/unexpected follow-up keys")
        expected_sequence = [(f"{op}/{pattern}/{count}", pair, variant)
                             for op, pattern, count, _ in CASES for pair in range(PAIRS)
                             for variant in (VARIANTS if pair % 2 == 0 else tuple(reversed(VARIANTS)))]
        check([(row["case"], row["pair"], row["variant"]) for row in observations] == expected_sequence,
              "Persisted follow-up order is not balanced alternating AB/BA")
        for op, pattern, count, iterations in CASES:
            case = f"{op}/{pattern}/{count}"
            rows = [keyed[(case, pair, variant)] for pair in range(PAIRS) for variant in VARIANTS]
            for row in rows:
                check(row["operation"] == op and row["pattern"] == pattern and row["count"] == count and row["iterations"] == iterations,
                      f"Case parameters differ: {case}")
            for field in ("fingerprint", "checksum", "locale", "warmup_checksum"):
                check(len({row[field] for row in rows}) == 1, f"Within-follow-up semantic identity differs: {case}/{field}")
            order_counts = Counter(tuple(keyed[(case, pair, "baseline")]["order"]) for pair in range(PAIRS))
            check(order_counts == {("baseline", "candidate"): 6, ("candidate", "baseline"): 6}, f"Unbalanced case: {case}")
            metrics = {}
            for metric in METRICS:
                before = [keyed[(case, pair, "baseline")][metric] for pair in range(PAIRS)]
                after = [keyed[(case, pair, "candidate")][metric] for pair in range(PAIRS)]
                changes = [(right - left) * 100.0 / left for left, right in zip(before, after)]
                metrics[metric] = {"baseline_median": median(before), "candidate_median": median(after),
                                   "paired_change_median_pct": median(changes),
                                   "baseline_range": [min(before), max(before)], "candidate_range": [min(after), max(after)]}
            rebuilt.append({"case": case, "metrics": metrics})
        equal(summary, rebuilt, "recomputed summary")
        counts = {"observations": len(observations), "unique_observation_keys": len(keyed),
                  "matching_measurement_command_receipts": len(commands), "successful_harness_build_receipts": 2,
                  "cases": 3, "pairs_per_case": PAIRS, "paired_comparisons": 36, "AB_pairs": 18, "BA_pairs": 18,
                  "metric_summaries_recomputed": 6, "linked_production_library_hashes": 2,
                  "followup_binary_hashes": 2, "observed_loop_ms_range": [min(duration_ms), max(duration_ms)],
                  "selected_cpu": manifest["measurement_cpu"], "initial_permitted_cpus": manifest["affinity"]}
        for name in ("manifest.json", "summary.json", "observations.jsonl", "commands.jsonl", "Harness.swift", "run.py"):
            data(followup / name)
        data(original / "manifest.json")
        data(original / "observations.jsonl")
    except Exception as exception:
        error = f"{type(exception).__name__}: {exception}"
        failures.append(error)
    script = Path(__file__).resolve()
    report = {"schema": "natural-filename-sort-targeted-followup-audit-v1",
              "audited_at_utc": datetime.now(timezone.utc).isoformat(),
              "auditor": {"path": str(script), "sha256": digest(script.read_bytes()), "python": sys.version.split()[0]},
              "followup": str(followup), "original": str(original), "passed": not failures,
              "checks": checks, "counts": counts, "failures": failures, "error": error,
              "recomputed_summary": rebuilt, "file_sha256": dict(sorted(hashes.items())),
              "scope": ["Read-only audit; no build or measurement rerun.",
                        "Same production library bytes as original cohort; only harness process-CPU timing added.",
                        "Affinity is supported by successful driver scheduling before child launches, not separate child-affinity receipts.",
                        "Targeted longer measurements neither replace the original adverse results nor prove their cause.",
                        "Wall/process-CPU component timings do not establish a general player speedup."]}
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
