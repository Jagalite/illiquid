#!/usr/bin/env python3
"""Independent, read-only audit of a source-visibility allocation cohort."""
import argparse, ast, collections, gzip, hashlib, json, math, pathlib, re, struct, subprocess, time

parser = argparse.ArgumentParser()
parser.add_argument('--evidence', required=True, type=pathlib.Path)
parser.add_argument('--repo', required=True, type=pathlib.Path)
parser.add_argument('--output', required=True, type=pathlib.Path)
parser.add_argument('--published-commit', required=True)
parser.add_argument('--published-tree', required=True)
args = parser.parse_args()
out, root = args.evidence, args.repo
m = json.loads((out / 'manifest.json').read_bytes())
errors, notices = [], []
sha = lambda x: hashlib.sha256(x).hexdigest()

def check(ok, message):
    if not ok: errors.append(message)

def jsonl(path):
    if not path.exists(): return []
    raw = path.read_bytes()
    lines = raw.splitlines()
    if raw and not raw.endswith(b'\n'):
        if m['complete']: errors.append('Incomplete final JSONL line: ' + path.name)
        else: notices.append('Ignored currently incomplete JSONL tail: ' + path.name)
        lines = lines[:-1]
    return [json.loads(line) for line in lines]

def git(rev, path):
    return subprocess.check_output(['git', '-C', str(root), 'show', rev + ':' + path])

# Reconstruct both source snapshots directly from receipt anchors, independently
# of the benchmark's staging helper, and check the actual compiled files.
originals, staged_checks, excerpt_checks = {}, 0, 0
for variant, sm in m['source_manifests'].items():
    raws = {}
    for name, record in sm['production'].items():
        rev = m['head'] if variant == 'candidate' else m['baseline']
        raw = git(rev, record['repository_path'])
        if variant == 'candidate':
            check(raw == (root / record['repository_path']).read_bytes(), 'Delivered source differs: ' + name)
        check(sha(raw) == record['source_sha256'], 'Production digest: ' + variant + '/' + name)
        check(hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == record['git_blob'], 'Git blob: ' + variant + '/' + name)
        if record['excerpts']:
            source, parts = raw.decode(), []
            for item in record['excerpts']:
                check(source.count(item['start']) == source.count(item['end']) == 1, 'Excerpt boundaries: ' + name)
                part = source[source.index(item['start']):source.index(item['end'])]
                check(sha(part.encode()) == item['sha256'], 'Excerpt digest: ' + name)
                parts.append(part); excerpt_checks += 1
            snapshot = ('import Foundation\nimport IlliquidCore\n\n' + '\n\n'.join(parts) + '\n').encode()
        else: snapshot = raw
        check(sha(snapshot) == record['snapshot_sha256'], 'Snapshot digest: ' + name)
        raws[name] = snapshot
    originals[variant] = raws
    for name, record in sm['staged'].items():
        compiled = (out / 'packages' / variant / name).read_bytes()
        check(sha(compiled) == record['compiled_sha256'], 'Compiled digest: ' + variant + '/' + name)
        if name in raws: raw = raws[name]
        elif name.startswith('Tests/'): raw = (root / name).read_bytes()
        elif name == 'Package.swift': raw = compiled
        else:
            relative = {'Sources/CVisibilityHeap/heap.c': 'CVisibilityHeap/heap.c',
                        'Sources/CVisibilityHeap/include/CVisibilityHeap.h': 'CVisibilityHeap/include/CVisibilityHeap.h',
                        'Sources/SourceVisibilityBenchmark/Harness.swift': 'Harness.swift'}[name]
            raw = (root / 'Benchmarks/SourceVisibilityStorage' / relative).read_bytes()
        check(sha(raw) == record['original_sha256'], 'Delivered staged origin: ' + variant + '/' + name)
        expected = raw
        if name.endswith('/MediaSidecarReader.swift'): expected = raw.replace(b'import Darwin\n', b'import Glibc\n', 1)
        elif name.endswith('/NFOMetadataHints.swift'): expected = raw.replace(b'import Foundation\n', b'import Foundation\nimport FoundationXML\n', 1)
        elif name.endswith('/SourceMediaOrganizationTests.swift'):
            expected = raw.replace(b'appendingPathComponent("media-sidecars-" + UUID().uuidString)', b'appendingPathComponent("media-sidecars-" + UUID().uuidString, isDirectory: true)', 1)
        check(expected == compiled, 'Unrecorded staging change: ' + variant + '/' + name)
        staged_checks += 1
changes = [name for name in originals['baseline'] if originals['baseline'][name] != originals['candidate'][name]]
check(changes == ['Sources/IlliquidApp/SourceBrowserFilter.swift'], 'Unexpected baseline/candidate production differences')
for field, path in [('runner_sha256', 'Benchmarks/SourceVisibilityStorage/run.py'), ('support_helper_sha256', 'Benchmarks/SourceTreeVisibility/run.py')]:
    check(sha((root / path).read_bytes()) == m[field], 'Delivered ' + field)
for name, digest in m['harness_hashes'].items():
    for variant in ['baseline', 'candidate']:
        check(sha((out / 'packages' / variant / name).read_bytes()) == digest, 'Harness digest: ' + variant + '/' + name)
helper = ast.parse((root / 'Benchmarks/SourceTreeVisibility/run.py').read_text())
package = next(ast.literal_eval(n.value) for n in helper.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PACKAGE' for t in n.targets))
package = package.replace('SourceTreeVisibilityQualification', 'SourceVisibilityStorage').replace('SourceTreeBenchmark', 'SourceVisibilityBenchmark')
package = package.replace('targets: [\n', 'targets: [\n        .target(name: "CVisibilityHeap", publicHeadersPath: "include"),\n', 1)
package = package.replace('dependencies: ["IlliquidCore", "IlliquidApp"]),', 'dependencies: ["IlliquidCore", "IlliquidApp", "CVisibilityHeap"]),', 1)
check(sha(package.encode()) == m['harness_hashes']['Package.swift'], 'Generated Package.swift')
measured_tree = subprocess.check_output(['git', '-C', str(root), 'rev-parse', m['head'] + '^{tree}']).decode().strip()
check(measured_tree == args.published_tree, 'Published tree differs from measured tree')

commands = jsonl(out / 'commands.jsonl')
by_label = {}
for command in commands:
    check(command['label'] not in by_label, 'Duplicate command label: ' + command['label'])
    by_label[command['label']] = command
    check(command['exit_status'] == (1 if command['label'] == 'negative-baseline-sharing' else 0), 'Unexpected command status: ' + command['label'])
tests = json.loads((out / 'tests.json').read_bytes())
for run in tests['runs']:
    label = 'tests-' + run['variant'] + '-' + run['configuration']
    command = by_label[label]; raw = (out / (label + '.log')).read_bytes()
    check(raw == (command['stdout'] + command['stderr']).encode(), 'Raw test log does not match command: ' + label)
    match = re.search(r'Test run with (\d+) tests?(?: in \d+ suites?)? passed', raw.decode())
    check(bool(match) and int(match.group(1)) == run['completed_test_functions'], 'Test count: ' + label)
negative = by_label['negative-baseline-sharing']
negative_text = negative['stdout'] + negative['stderr']
check(negative['exit_status'] == 1 and negative_text.count('Expectation failed:') == 2 and 'original.baseAddress' in negative_text, 'Sharing negative control did not fail as intended')

# Parse every byte of the independent full-output encoding, not just its hash.
class Snapshot:
    def __init__(self, data): self.data, self.offset = data, 0
    def u64(self):
        if self.offset + 8 > len(self.data): raise ValueError('Truncated snapshot integer')
        value = struct.unpack_from('<Q', self.data, self.offset)[0]; self.offset += 8; return value
    def text(self):
        size = self.u64()
        if self.offset + size > len(self.data): raise ValueError('Truncated snapshot string')
        value = self.data[self.offset:self.offset + size].decode(); self.offset += size; return value
    def optional(self):
        marker = self.u64()
        if marker not in (0, 1): raise ValueError('Invalid snapshot optional marker')
        return self.text() if marker else None
    def parse(self):
        rows = self.u64()
        for _ in range(rows):
            for _ in range(4): self.text()
            self.optional(); self.optional(); self.u64()
            for _ in range(self.u64()): self.text()
            kind = self.text()
            if kind == 'folder': self.u64()
            elif kind == 'media': self.optional()
            elif kind == 'message': self.text()
            elif kind != 'mediaSection': raise ValueError('Unknown row kind')
            visibility = self.u64()
            if visibility not in (0, 1): raise ValueError('Invalid visibility marker')
            if visibility:
                self.u64()
                for _ in range(self.u64()):
                    match = self.text()
                    if match == 'regex': self.text(); self.u64()
                    elif match not in ('manual', 'noMedia'): raise ValueError('Unknown visibility match')
            self.optional()
            recognized = self.u64()
            if recognized not in (0, 1): raise ValueError('Invalid recognition marker')
            if recognized:
                self.text(); self.text()
                for _ in range(8): self.optional()
                for _ in range(self.u64()): self.text()
                for _ in range(self.u64()): self.text()
        hidden = self.u64(); counts = {}
        for _ in range(self.u64()):
            name = self.text(); counts[name] = self.u64()
        thumbnails = self.u64()
        for _ in range(thumbnails): self.text()
        paths = self.u64()
        for _ in range(paths): self.text()
        if self.offset != len(self.data): raise ValueError('Unparsed snapshot tail')
        return {'output_rows': rows, 'hidden_count': hidden, 'regex_counts': counts, 'thumbnail_count': thumbnails, 'media_path_count': paths}

def fnv(data):
    value = 14695981039346656037
    for b in data: value = ((value ^ b) * 1099511628211) & ((1 << 64) - 1)
    return format(value, 'x')

verification = json.loads((out / 'verification.json').read_bytes())
expected_verification = {(case, size) for case in m['cases'] for size in [0, 1, 31, 257]}
check({(v['scenario'], v['size']) for v in verification} == expected_verification and len(verification) == len(expected_verification), 'Incomplete verification matrix')
for record in verification:
    values = []
    for variant in ['baseline', 'candidate']:
        name = 'verify-' + record['scenario'] + '-' + str(record['size']) + '-' + variant
        data = gzip.decompress((out / (name + '.bin.gz')).read_bytes())
        observed = json.loads(by_label[name]['stdout'])
        check(len(data) == record['bytes'] == observed['snapshot_bytes'], 'Verification length: ' + name)
        check(sha(data) == record['sha256'], 'Verification SHA: ' + name)
        check(fnv(data) == observed['snapshot_checksum'], 'Verification fingerprint: ' + name)
        parsed = Snapshot(data).parse()
        check(all(observed[k] == v for k, v in parsed.items()), 'Snapshot contents/receipt: ' + name)
        values.append(data)
    check(values[0] == values[1] and record['exact_bytes_equal'], 'Exact verification parity: ' + name)

observations = jsonl(out / 'observations.jsonl')
summaries = json.loads((out / 'summary.json').read_bytes()) if (out / 'summary.json').exists() else []
semantic_keys = ['scenario','size','row_stride','output_rows','hidden_count','regex_counts','thumbnail_count','media_path_count','snapshot_bytes','snapshot_checksum']
metrics = ['retained_allocator_delta_bytes','wall_nanoseconds','cpu_nanoseconds']
groups, unique = collections.defaultdict(list), set()
for item in observations:
    key = (item['scenario'], item['size'], item['pair'], item['variant'])
    check(key not in unique, 'Duplicate observation: ' + repr(key)); unique.add(key)
    check(item['scenario'] in m['cases'] and item['size'] in m['sizes'] and item['pair'] in range(m['pairs']) and item['variant'] in ['baseline','candidate'], 'Observation outside matrix: ' + repr(key))
    groups[key[:2]].append(item)
    check(item['heap_live'] - item['heap_before'] == item['retained_allocator_delta_bytes'], 'Allocator arithmetic: ' + repr(key))
    check(item['wall_nanoseconds'] > 0 and item['cpu_nanoseconds'] > 0, 'Invalid timing: ' + repr(key))
    check(item['output_row_capacity'] >= item['output_rows'], 'Output capacity: ' + repr(key))
    if item['scenario'] != 'tree_input': check(item['input_row_capacity'] >= item['size'], 'Input capacity: ' + repr(key))
    if item['scenario'] in ['unchanged','nonmatching_rule']:
        check(item['input_output_share_rows'] == (item['variant'] == 'candidate'), 'Sharing invariant: ' + repr(key))
        if item['variant'] == 'candidate': check(item['input_row_capacity'] == item['output_row_capacity'], 'Shared capacity mismatch: ' + repr(key))
    else: check(item.get('input_output_share_rows') in [False, None], 'Unexpected control sharing: ' + repr(key))
    expected_order = 0 if (item['pair'] % 2 == 0) == (item['variant'] == 'baseline') else 1
    check(item['process_order'] == expected_order, 'AB/BA position: ' + repr(key))
    label = 'measure-' + item['scenario'] + '-' + str(item['size']) + '-' + str(item['pair']) + '-' + item['variant']
    command = by_label.get(label)
    check(command is not None, 'Missing command: ' + label)
    if command:
        check({k:v for k,v in item.items() if k not in ['variant','pair','process_order']} == json.loads(command['stdout']), 'Observation differs from raw stdout: ' + label)

def median(values):
    s = sorted(values); k = len(s) // 2
    return s[k] if len(s) % 2 else (s[k - 1] + s[k]) / 2

def equivalent(a, b):
    if isinstance(a, dict): return isinstance(b, dict) and a.keys() == b.keys() and all(equivalent(a[k],b[k]) for k in a)
    if isinstance(a, list): return isinstance(b, list) and len(a) == len(b) and all(equivalent(x,y) for x,y in zip(a,b))
    if isinstance(a, (int,float)) and isinstance(b, (int,float)): return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-8)
    return a == b

numeric, seen_summaries = [], set()
for summary in summaries:
    key = (summary['scenario'],summary['size'])
    check(key not in seen_summaries, 'Duplicate summary: ' + repr(key)); seen_summaries.add(key)
    items = groups[key]
    check(len(items) == m['pairs'] * 2 and summary['pairs'] == m['pairs'], 'Incomplete summarized group: ' + repr(key))
    if len(items) != m['pairs'] * 2: continue
    reference = {k:items[0][k] for k in semantic_keys}
    check(all({k:i[k] for k in semantic_keys} == reference for i in items), 'Measured semantic mismatch: ' + repr(key))
    check([(i['pair'],i['process_order']) for i in items] == [(p,pos) for p in range(m['pairs']) for pos in [0,1]], 'Chronological observation ordering: ' + repr(key))
    pairmap = {(i['pair'],i['variant']):i for i in items}; recomputed = {}
    for metric in metrics:
        before = [pairmap[p,'baseline'][metric] for p in range(m['pairs'])]
        after = [pairmap[p,'candidate'][metric] for p in range(m['pairs'])]
        recomputed[metric] = {'baseline_median':median(before),'candidate_median':median(after),'baseline_range':[min(before),max(before)],'candidate_range':[min(after),max(after)],'median_paired_difference':median([b-a for b,a in zip(before,after)]),'median_paired_reduction_percent':median([100*(b-a)/b for b,a in zip(before,after)]) if all(b>0 for b in before) else None,'favorable_pairs':sum(a<b for b,a in zip(before,after))}
    check(equivalent(recomputed,summary['metrics']), 'Recomputed summary differs: ' + repr(key))
    numeric.append({'scenario':key[0],'size':key[1],'metrics':recomputed,'baseline_capacities':sorted({i['output_row_capacity'] for i in items if i['variant']=='baseline'}),'candidate_capacities':sorted({i['output_row_capacity'] for i in items if i['variant']=='candidate'}),'AB_pairs':sum(i['variant']=='baseline' and i['process_order']==0 for i in items),'BA_pairs':sum(i['variant']=='candidate' and i['process_order']==0 for i in items)})
expected_groups = {(c,s) for c in m['cases'] for s in m['sizes']}
if m['complete']:
    check(len(observations) == m['observations'] == len(expected_groups)*m['pairs']*2, 'Final observation count')
    check(seen_summaries == expected_groups, 'Final matrix incomplete')
    for variant,digest in m['binary_hashes'].items():
        executable = pathlib.Path(by_label['bin-path-'+variant]['stdout'].strip())/'SourceVisibilityBenchmark'
        check(sha(executable.read_bytes()) == digest, 'Measured binary digest: ' + variant)

report = {'schema':1,'phase':'final' if m['complete'] else 'interim','complete_run':m['complete'],'audited_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'evidence':str(out),'measured_commit':m['head'],'published_commit':args.published_commit,'common_tree':measured_tree,'staged_files_verified':staged_checks,'excerpt_sections_verified':excerpt_checks,'test_counts':[r['completed_test_functions'] for r in tests['runs']],'verification_cases':len(verification),'verification_snapshots':len(verification)*2,'observations_read':len(observations),'completed_groups_audited':len(numeric),'expected_groups':len(expected_groups),'all_groups':numeric,'notices':notices,'errors':errors,'limitations':['At-return live allocator growth with fixture/actor/result held; no forced autorelease drain or quiescence','Component allocation measurement, not peak, RSS, physical footprint or whole-player memory','36 small scenarios compare all encoded bytes; measured large cases compare complete-state FNV64 fingerprints plus semantic fields','Timing controls are reported whether favorable or unfavorable; no whole-player speed claim','Native macOS qualification remains pending unless separately supplied']}
args.output.parent.mkdir(parents=True,exist_ok=True); args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='all_groups'},indent=2))
for row in numeric:
    ms=row['metrics']; mem=ms['retained_allocator_delta_bytes'];wall=ms['wall_nanoseconds'];cpu=ms['cpu_nanoseconds']
    print(json.dumps({'scenario':row['scenario'],'size':row['size'],'allocation_before':mem['baseline_median'],'allocation_after':mem['candidate_median'],'allocation_reduction_pct':mem['median_paired_reduction_percent'],'wall_reduction_pct':wall['median_paired_reduction_percent'],'cpu_reduction_pct':cpu['median_paired_reduction_percent'],'baseline_capacity':row['baseline_capacities'],'candidate_capacity':row['candidate_capacities'],'AB_BA':[row['AB_pairs'],row['BA_pairs']]}))
if errors: raise SystemExit(1)
