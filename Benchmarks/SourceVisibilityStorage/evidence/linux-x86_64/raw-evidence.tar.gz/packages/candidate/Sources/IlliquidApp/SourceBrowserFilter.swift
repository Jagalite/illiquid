import Foundation

struct SourceBrowserProjection: Sendable {
    let rows: [SourceTreeDisplayRow]
    let hiddenCount: Int
    let regexCounts: [String: Int]
    let thumbnailCandidates: [URL]
    let mediaPaths: Set<String>

    init(rows: [SourceTreeDisplayRow], hiddenCount: Int, regexCounts: [String: Int]) {
        self.rows = rows
        self.hiddenCount = hiddenCount
        self.regexCounts = regexCounts
        var candidates: [URL] = [], paths: Set<String> = []
        for row in rows {
            guard case .media = row.kind else { continue }
            if candidates.count < 2048 { candidates.append(row.url) }
            paths.insert(row.url.standardizedFileURL.path)
        }
        thumbnailCandidates = candidates
        mediaPaths = paths
    }
}

/// Serial background projection. Search changes reuse the visibility result,
/// including compiled-rule evaluation; only source or rule changes rebuild it.
actor SourceBrowserFilter {
    private var cachedInput: SourceTreeProjectionInput?
    private var cachedRows: [SourceTreeDisplayRow] = []
    private(set) var treeBuildCount = 0

    func project(input: SourceTreeProjectionInput, revealsRulePreview: Bool,
                 query: String) -> SourceBrowserProjection? {
        guard !Task.isCancelled else { return nil }
        if cachedInput.map({ input.hasSameTree(as: $0) }) != true {
            let rows = input.rows()
            guard !Task.isCancelled else { return nil }
            cachedRows = rows
            treeBuildCount += 1
        }
        // Retain the current snapshot even on a tree cache hit, so removed
        // visibility rules and path sets are released with the old snapshot.
        cachedInput = input
        return project(rows: cachedRows, configuration: input.visibility,
                       roots: input.roots, revealsRulePreview: revealsRulePreview, query: query)
    }

    private(set) var visibilityBuildCount = 0
    private struct Key: Equatable {
        let rows: [SourceTreeDisplayRow]
        let configuration: SourceVisibilityConfiguration
        let roots: [URL]
        let revealsRulePreview: Bool
    }
    private var cachedKey: Key?
    private var cachedProjection: SourceBrowserProjection?

    func project(
        rows: [SourceTreeDisplayRow], configuration: SourceVisibilityConfiguration,
        roots: [URL], revealsRulePreview: Bool, query: String
    ) -> SourceBrowserProjection? {
        guard !Task.isCancelled else { return nil }
        let key = Key(rows: rows, configuration: configuration, roots: roots,
                      revealsRulePreview: revealsRulePreview)
        if key != cachedKey {
            visibilityBuildCount += 1
            guard let projection = visibility(
                from: rows, configuration: configuration, roots: roots,
                revealsRulePreview: revealsRulePreview
            ) else { return nil }
            cachedProjection = projection
            cachedKey = key
        }
        guard let projection = cachedProjection else { return nil }
        // Clearing search restores the existing projection. Rebuilding its path
        // set needlessly normalizes every URL again in a large library.
        if configuration.viewMode != .media,
           query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return projection
        }
        let searched = Self.search(projection.rows, query: query)
        let result = configuration.viewMode == .media
            ? Self.organizeMedia(searched) : searched
        guard !Task.isCancelled else { return nil }
        return SourceBrowserProjection(rows: result, hiddenCount: projection.hiddenCount,
                                       regexCounts: projection.regexCounts)
    }

    private func visibility(
        from allRows: [SourceTreeDisplayRow],
        configuration: SourceVisibilityConfiguration, roots: [URL],
        revealsRulePreview: Bool
    ) -> SourceBrowserProjection? {
        let matcher = SourceVisibilityMatcher(configuration: configuration, roots: roots)
        let evaluatesVisibility =
            !configuration.manuallyHiddenPaths.isEmpty
            || !configuration.alwaysShownPaths.isEmpty
            || configuration.regexRules.contains { $0.isEnabled }
        let revealsHiddenItems = configuration.showsHiddenItems
            || revealsRulePreview
        var hiddenFolders: [String: SourceRowVisibility] = [:]
        var counts = Dictionary(
            uniqueKeysWithValues: configuration.regexRules.map { ($0.id, 0) }
        )
        var hiddenCount = 0
        // The tree cache already retains allRows. Share that immutable storage
        // when visibility leaves every row unannotated and included; materialize
        // the accepted prefix only when the output first differs. A nonnil old
        // annotation still takes the original assignment path, including when
        // the new annotation compares equal but contains different String bytes.
        var rows: [SourceTreeDisplayRow]?

        for (index, original) in allRows.enumerated() {
            guard !Task.isCancelled else { return nil }
            var row = original
            if !SourceVisibilityProjection.includes(
                row.kind.itemKind,
                in: configuration.viewMode
            ) {
                if rows == nil { rows = Array(allRows[..<index]) }
                continue
            }

            let inheritedVisibility = row.ancestorIDs.lazy.compactMap {
                hiddenFolders[$0]
            }.first
            let evaluation = if evaluatesVisibility,
                                let visibilityPath = row.visibilityPath
            {
                configuration.viewMode.scansRecursively
                    ? matcher.evaluateIncludingAncestors(
                        normalizedPath: visibilityPath
                    )
                    : matcher.evaluate(normalizedPath: visibilityPath)
            } else if evaluatesVisibility {
                configuration.viewMode.scansRecursively
                    ? matcher.evaluateIncludingAncestors(row.url)
                    : matcher.evaluate(row.url)
            } else {
                SourceVisibilityEvaluation(
                    hiddenMatches: [],
                    regexMatches: []
                )
            }
            for match in evaluation.regexMatches {
                counts[match.id, default: 0] += 1
            }

            var hiddenMatches = evaluation.hiddenMatches
            if case .folder = row.kind, row.containsSupportedMedia == false,
               let path = row.visibilityPath ?? SourceVisibilityPath.normalized(row.url),
               !configuration.alwaysShownPaths.contains(path) {
                hiddenMatches.append(.noMedia)
            }
            let directVisibility = hiddenMatches.isEmpty
                ? nil
                : SourceRowVisibility(
                    matches: hiddenMatches,
                    isInherited: false
                )
            let visibility = inheritedVisibility.map {
                SourceRowVisibility(matches: $0.matches, isInherited: true)
            } ?? directVisibility

            if case .folder = row.kind, let visibility {
                hiddenFolders[row.id] = visibility
            }
            if visibility != nil, row.kind.itemKind != nil {
                hiddenCount += 1
            }
            guard visibility == nil || revealsHiddenItems else {
                if rows == nil { rows = Array(allRows[..<index]) }
                continue
            }
            if rows == nil, row.visibility != nil || visibility != nil {
                rows = Array(allRows[..<index])
            }
            row.visibility = visibility
            // A late changed row can fill an almost-complete copied prefix.
            // Cap requested growth at the input size, while retaining geometric
            // growth for small filtered results. reserveCapacity may round up.
            if let outputCount = rows?.count, outputCount == rows?.capacity {
                let growth = min(max(outputCount, 1), allRows.count - outputCount)
                rows?.reserveCapacity(outputCount + growth)
            }
            rows?.append(row)
        }

        return SourceBrowserProjection(rows: rows ?? allRows, hiddenCount: hiddenCount, regexCounts: counts)
    }

    private static func organizeMedia(_ rows: [SourceTreeDisplayRow]) -> [SourceTreeDisplayRow] {
        // Case variations in release names should not split a season.
        var canonicalTitles: [String: String] = [:]
        // Most rows share a section. Reuse folding for repeated spellings,
        // retaining this projection's first encountered spelling as the title.
        var canonicalByTitle: [String: (raw: String, canonical: String)] = [:]
        let locale = Locale(identifier: "en_US_POSIX")
        let sections = Dictionary(grouping: rows) { row in
            let title = row.recognizedMedia?.section ?? "Other Videos"
            // String keys equate canonical Unicode spellings. Reuse folding
            // only for identical bytes, preserving Foundation's original input.
            if let cached = canonicalByTitle[title],
               cached.raw.utf8.elementsEqual(title.utf8) {
                return cached.canonical
            }
            let key = title.folding(options: .caseInsensitive, locale: locale)
            let canonical = canonicalTitles[key] ?? title
            canonicalTitles[key] = canonical
            canonicalByTitle[title] = (title, canonical)
            return canonical
        }
        func rank(_ title: String) -> Int {
            if title == "Movies" { return 0 }
            if title.hasPrefix("TV Shows · ") { return 1 }
            return title == "Extras" ? 2 : 3
        }
        let titles = sections.keys.sorted {
            if rank($0) != rank($1) { return rank($0) < rank($1) }
            return $0.localizedStandardCompare($1) == .orderedAscending
        }
        var result: [SourceTreeDisplayRow] = []
        for title in titles {
            guard !Task.isCancelled else { return [] }
            guard let members = sections[title], let first = members.first else { continue }
            result.append(SourceTreeDisplayRow(
                id: "media-section:\(title)", folderID: "", url: first.url,
                displayName: "\(title) (\(members.count))", depth: 0,
                ancestorIDs: [], kind: .mediaSection))
            // Episode order has semantic meaning; retain the selected file sort
            // for movies, extras, unknown files, and alternate versions of an episode.
            if first.recognizedMedia?.kind == .episode {
                result.append(contentsOf: members.enumerated().sorted { lhs, rhs in
                    guard let a = lhs.element.recognizedMedia, let b = rhs.element.recognizedMedia
                    else { return lhs.offset < rhs.offset }
                    if a.episode != b.episode { return (a.episode ?? 0) < (b.episode ?? 0) }
                    if a.airDate != b.airDate { return (a.airDate ?? "") < (b.airDate ?? "") }
                    return lhs.offset < rhs.offset
                }.map(\.element))
            } else {
                result.append(contentsOf: members)
            }
        }
        return result
    }

    static func search(_ rows: [SourceTreeDisplayRow], query: String) -> [SourceTreeDisplayRow] {
        let query = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return rows }
        let matchingRows = rows.filter {
            guard !Task.isCancelled else { return false }
            switch $0.kind {
            case .folder, .media:
                if $0.displayName.localizedCaseInsensitiveContains(query) { return true }
                guard let media = $0.recognizedMedia else { return false }
                return $0.url.lastPathComponent.localizedCaseInsensitiveContains(query)
                    || media.section.localizedCaseInsensitiveContains(query)
                    || media.catalogIDs.contains { $0.localizedCaseInsensitiveContains(query) }
                    || ($0.contextLabel?.localizedCaseInsensitiveContains(query) ?? false)
            case .message, .mediaSection:
                return false
            }
        }
        var visibleIDs = Set<String>(minimumCapacity: matchingRows.count)
        for row in matchingRows {
            visibleIDs.insert(row.id)
            visibleIDs.formUnion(row.ancestorIDs)
        }
        return rows.filter { visibleIDs.contains($0.id) }
    }
}
