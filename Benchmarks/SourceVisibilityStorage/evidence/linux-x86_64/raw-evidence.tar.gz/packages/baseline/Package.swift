// swift-tools-version: 6.1
import PackageDescription
let package = Package(
    name: "SourceVisibilityStorage",
    platforms: [.macOS("26.0")],
    products: [.executable(name: "SourceVisibilityBenchmark", targets: ["SourceVisibilityBenchmark"])],
    targets: [
        .target(name: "CVisibilityHeap", publicHeadersPath: "include"),
        .target(name: "IlliquidCore"),
        // The driver needs internal APIs; tests never link its @main entry point.
        .target(name: "IlliquidApp", dependencies: ["IlliquidCore"],
                swiftSettings: [.unsafeFlags(["-enable-testing"])]),
        .executableTarget(name: "SourceVisibilityBenchmark", dependencies: ["IlliquidCore", "IlliquidApp", "CVisibilityHeap"]),
        .testTarget(name: "IlliquidAppTests", dependencies: ["IlliquidCore", "IlliquidApp"]),
    ]
)
