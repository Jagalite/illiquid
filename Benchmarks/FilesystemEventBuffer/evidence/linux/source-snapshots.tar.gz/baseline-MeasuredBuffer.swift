// Original accumulator statements extracted from the pinned SourcesSidebar.swift.
struct MeasuredBuffer {
    private var pendingFilesystemEvents: [SourceFilesystemEvent] = []
    var count: Int { pendingFilesystemEvents.count }
    mutating func append(contentsOf events: [SourceFilesystemEvent]) {
        pendingFilesystemEvents.append(contentsOf: events)
    }
    mutating func take() -> [SourceFilesystemEvent] {
        let events = pendingFilesystemEvents
        pendingFilesystemEvents.removeAll()
        return events
    }
    mutating func removeAll() { pendingFilesystemEvents.removeAll() }
}
