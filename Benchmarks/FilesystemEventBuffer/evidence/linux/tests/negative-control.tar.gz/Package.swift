// swift-tools-version: 6.1
import PackageDescription
let package = Package(name: "IlliquidEventBufferNegativeControl", targets: [
    .target(name: "IlliquidApp"),
    .testTarget(name: "IlliquidAppTests", dependencies: ["IlliquidApp"])
])
