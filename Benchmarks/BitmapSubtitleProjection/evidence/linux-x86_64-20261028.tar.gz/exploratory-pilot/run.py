#!/usr/bin/env python3
"""Exploratory comparison of actual bitmap subtitle region projection."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "illiquid-bitmap"
BASE = "ea2ff568237e2667f7b1aeee67b11a44ebe95b72"
SWIFTC = HERE.parent / "toolchains/swift-6.3.2-RELEASE-ubuntu24.04/usr/bin/swiftc"
ENV = dict(os.environ, LD_LIBRARY_PATH=str(HERE.parent / "toolchains/swift-runtime/usr/lib/x86_64-linux-gnu"))
FLAGS = ["-O", "-whole-module-optimization", "-swift-version", "6", "-warnings-as-errors"]
VARIANTS = ("baseline", "candidate")
logs = HERE / "logs"
logs.mkdir(exist_ok=True)


def run(args, name):
    args = list(map(str, args))
    start = time.monotonic()
    result = subprocess.run(args, cwd=ROOT, env=ENV, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (logs / (name + ".log")).write_text(result.stdout)
    with (HERE / "commands.jsonl").open("a") as stream:
        stream.write(json.dumps({"args": args, "exit_code": result.returncode,
            "elapsed_seconds": time.monotonic() - start, "log": name + ".log"}) + "\n")
    if result.returncode:
        raise RuntimeError(result.stdout)
    return result.stdout


def source(path):
    return run(["git", "show", f"{BASE}:{path}"], "source-" + Path(path).stem)


def sha(value):
    return hashlib.sha256(value.encode()).hexdigest()


original = source("Sources/IlliquidNativePlayback/Subtitles/BitmapSubtitleTimeline.swift")
needle = "        return regions.filter { !forcedOnly || $0.isForced }.map { region in"
replacement = "        let visibleRegions = forcedOnly ? regions.filter(\\.isForced) : regions\n        return visibleRegions.map { region in"
assert original.count(needle) == 1
candidate = original.replace(needle, replacement)
budget = source("Sources/IlliquidNativePlayback/Subtitles/SubtitleMemoryBudget.swift")
libass = source("Sources/IlliquidNativePlayback/Subtitles/LibassContext.swift")
start = "struct ASSRenderedRegion: Sendable {"
end = "struct ASSRenderResult: Sendable {"
assert libass.count(start) == libass.count(end) == 1
region = "import Foundation\n\n" + libass[libass.index(start):libass.index(end)]
manifest = {"base": BASE, "timeline_original_sha256": sha(original), "timeline_candidate_sha256": sha(candidate),
    "budget_sha256": sha(budget), "libass_sha256": sha(libass), "region_extraction_sha256": sha(region),
    "adaptation": "Only import CoreGraphics removed from timeline on Linux; Foundation CGRect/CGSize and exact production types retained.",
    "swift": run([SWIFTC, "--version"], "swift-version"), "flags": FLAGS,
    "scope": "Complete renderedRegions(in:forcedOnly:) projection plus result consumption/release. Fixture creation, receipt serialization excluded."}
(HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
binaries = {}
for variant, timeline in (("baseline", original), ("candidate", candidate)):
    folder = HERE / variant
    folder.mkdir(exist_ok=True)
    (folder / "BitmapSubtitleTimeline.swift").write_text(timeline.replace("import CoreGraphics\n", ""))
    (folder / "SubtitleMemoryBudget.swift").write_text(budget)
    (folder / "ASSRenderedRegion.swift").write_text(region)
    sources = [folder / name for name in ("BitmapSubtitleTimeline.swift", "SubtitleMemoryBudget.swift", "ASSRenderedRegion.swift")]
    run([SWIFTC, *FLAGS, "-enable-testing", "-emit-library", "-emit-module", "-module-name", "IlliquidNativePlayback",
         "-module-cache-path", HERE / "module-cache", "-emit-module-path", folder / "IlliquidNativePlayback.swiftmodule",
         *sources, "-o", folder / "libIlliquidNativePlayback.so"], "compile-" + variant)
    binary = folder / "projection-benchmark"
    run([SWIFTC, *FLAGS, "-parse-as-library", "-module-cache-path", HERE / "module-cache", "-I", folder, "-L", folder,
         "-lIlliquidNativePlayback", "-Xlinker", "-rpath", "-Xlinker", folder, HERE / "Driver.swift", "-o", binary], "driver-" + variant)
    binaries[variant] = binary
verification = {}
for variant, binary in binaries.items():
    verification[variant] = json.loads(run([binary, "verify"], "verify-" + variant))
    (HERE / ("verification-" + variant + ".json")).write_text(json.dumps(verification[variant], sort_keys=True) + "\n")
assert verification["baseline"] == verification["candidate"]
print(f"Exact output parity: {len(verification['baseline'])} fixtures", flush=True)
cases = json.loads(run([binaries["baseline"], "list"], "list"))
counts = {}
for name in cases:
    elapsed = []
    for variant in VARIANTS:
        probe = json.loads(run([binaries[variant], name, 1000], f"probe-{name}-{variant}"))
        elapsed.append(probe["cpu_ns_per_projection"])
        with (HERE / "calibration.jsonl").open("a") as stream:
            stream.write(json.dumps(dict(probe, variant=variant)) + "\n")
    counts[name] = min(2_000_000, max(1000, int(30_000_000 / min(elapsed))))
rows = []
for pair in range(4):
    for name in cases:
        order = VARIANTS if pair % 2 == 0 else tuple(reversed(VARIANTS))
        pair_rows = {}
        for position, variant in enumerate(order):
            row = json.loads(run([binaries[variant], name, counts[name]], f"timing-{pair}-{name}-{variant}"))
            row.update(pair=pair, variant=variant, position=position)
            rows.append(row)
            pair_rows[variant] = row
            with (HERE / "observations.jsonl").open("a") as stream:
                stream.write(json.dumps(row) + "\n")
        for key in ("workload", "iterations", "checksum", "warmup_checksum", "warmup_iterations", "input_region_count"):
            assert pair_rows["baseline"][key] == pair_rows["candidate"][key], (name, key)
    print(f"Round {pair+1}/4", flush=True)
summary = []
for name in cases:
    selected = [row for row in rows if row["workload"] == name]
    values = {variant: [row["cpu_ns_per_projection"] for row in selected if row["variant"] == variant] for variant in VARIANTS}
    ratios = [b / a for a, b in zip(values["baseline"], values["candidate"])]
    result = dict(name=name, baseline_ns=statistics.median(values["baseline"]), candidate_ns=statistics.median(values["candidate"]),
        cpu_reduction_percent=100 * (1-statistics.median(ratios)), faster_pairs=sum(ratio < 1 for ratio in ratios), ratios=ratios)
    summary.append(result)
    print(json.dumps(result), flush=True)
(HERE / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
