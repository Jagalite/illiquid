#!/usr/bin/env python3
"""A predeclared follow-up of adverse bitmap-projection controls.

Uses the exact already-tested module/driver binaries; no rebuild or code change.
The original complete campaign remains the primary report and is not replaced.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--prior-output", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
prior = args.prior_output.resolve()
out = args.output.resolve()
if out.exists() and any(out.iterdir()):
    raise SystemExit("Refusing to overwrite previous evidence")
out.mkdir(parents=True, exist_ok=True)
runner_path = prior / "inputs/run.py"
spec = importlib.util.spec_from_file_location("bitmap_projection_runner", runner_path)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
# The original runner's working directory is restored from its recorded manifest.
commands = [json.loads(line) for line in (prior / "commands.jsonl").read_text().splitlines()]
runner.ROOT = Path(commands[0]["cwd"])
run = runner.Run(out)
manifest = json.loads((prior / "manifest.json").read_text())
binaries = {}
for variant in runner.VARIANTS:
    folder = prior / "build" / variant
    binaries[variant] = folder / "bitmap-projection"
    for key, path in [("driver", binaries[variant]), ("module", folder / "libIlliquidNativePlayback.so")]:
        assert runner.file_digest(path) == manifest["build_sha256"][variant][key], (variant, key)
workloads = ["unforced-0", "forced-some-64", "forced-all-64", "forced-none-64", "unforced-2"]
plan = {
    "purpose": "Resolve adverse forced-some-64 control from the complete Linux campaign; retain empty-output tradeoff and three comparison controls.",
    "selection_is_posthoc": True,
    "original_campaign_retained": True,
    "workloads": workloads,
    "pairs": 20,
    "target_cpu_ms": 500,
    "protocol": "Original runner calibration and balanced fresh-process AB/BA pairing; all five workloads interleaved across rounds; no observations dropped. Ten-million-iteration cap may leave empty/none controls below target.",
    "interpretation": "Report both campaigns. If forced-some-64 repeats a material adverse result, keep the optimization unqualified pending native data; do not relabel a failed control as noise. This follow-up cannot establish macOS performance or global control neutrality.",
    "source_commit": "0b82a8d7a05eda7aac79d2ee9ec5f08f26144f79",
    "prior_manifest_sha256": runner.file_digest(prior / "manifest.json"),
    "prior_summary_sha256": runner.file_digest(prior / "summary.json"),
    "runner_sha256": runner.file_digest(runner_path),
    "binaries_sha256": manifest["build_sha256"],
}
runner.save(out / "plan.json", plan)
shutil.copyfile(__file__, out / "followup.py")
shutil.copyfile(runner_path, out / "run.py")
summary = {"status": "running", "mode": "control-followup", "pairs": 20,
           "target_ms": 500, "tests": "Unchanged tested binaries; see original campaign", "workloads": []}
runner.save(out / "summary.json", summary)
try:
    names = runner.parity(run, binaries, summary)
    assert set(workloads) <= set(names)
    assert summary["verification"]["receipt_sha256"] == json.loads((prior / "summary.json").read_text())["verification"]["receipt_sha256"]
    runner.measure(run, binaries, workloads, argparse.Namespace(pairs=20, target_ms=500), summary)
    summary["status"] = "passed"
finally:
    runner.save(out / "summary.json", summary)
