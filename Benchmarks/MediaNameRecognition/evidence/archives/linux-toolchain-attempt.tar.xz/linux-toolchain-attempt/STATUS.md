# Pre-qualification toolchain attempt

The first compiler-version command exited 127 because the sandbox runtime could not load libswiftCore.so. No tests or timings ran. The separate successful Linux qualification used the working toolchain environment. This attempt is retained for completeness and is excluded from all results.
