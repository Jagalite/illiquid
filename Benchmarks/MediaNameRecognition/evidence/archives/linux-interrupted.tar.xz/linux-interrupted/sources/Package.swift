// swift-tools-version: 6.0
import PackageDescription
let package = Package(
    name: "MediaNameRecognitionQualification",
    products: [.library(name: "IlliquidCore", targets: ["IlliquidCore"])],
    targets: [
        .target(name: "IlliquidCore"),
        .testTarget(name: "IlliquidCoreTests", dependencies: ["IlliquidCore"])
    ]
)
