# Incomplete attempt; excluded from timing conclusions

The research session reported disk exhaustion while recording the next timing
process. Only 86 of the required 96 measurement rows are present, and the final
`timing-086-dated-forward-candidate.log` has no corresponding completed command
or measurement receipt. There is no summary or overall verification receipt.

The successful baseline/candidate differential comparison contains 188,534
records. That correctness evidence is retained, but no aggregate performance
claim is made from this incomplete cohort. The final six-pair timing result is
the separate complete `../linux/` cohort.

The disk-exhaustion cause is recorded from the research session; the stored
successful command receipts precede the interruption.
