import Foundation
@main struct Probe {
    static func main() {
        FileHandle.standardError.write(Data("before NSString.deletingLastPathComponent\n".utf8))
        print(("." as NSString).deletingLastPathComponent)
        FileHandle.standardError.write(Data("after NSString.deletingLastPathComponent\n".utf8))
    }
}
