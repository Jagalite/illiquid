import Foundation
import IlliquidCore
@main struct Probe {
    static func main() {
        let path = CommandLine.arguments[1]
        FileHandle.standardError.write(Data("before recognize \(path)\n".utf8))
        print(MediaNameRecognition.recognize(relativePath: path))
        FileHandle.standardError.write(Data("after recognize\n".utf8))
    }
}
