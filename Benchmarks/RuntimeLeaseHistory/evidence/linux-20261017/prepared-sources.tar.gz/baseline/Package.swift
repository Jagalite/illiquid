// swift-tools-version: 6.1
import PackageDescription
let package = Package(name: "RuntimeLeaseHistory", platforms: [.macOS("26.0")],
    products: [.executable(name: "RuntimeLeaseHistory", targets: ["IlliquidNativePlayback"])],
    targets: [
        .target(name: "CLeaseHeap", publicHeadersPath: "include"),
        .target(name: "IlliquidCore"),
        .target(name: "IlliquidPlaybackCore", dependencies: ["IlliquidCore"]),
        .executableTarget(name: "IlliquidNativePlayback", dependencies: ["IlliquidPlaybackCore", "CLeaseHeap"]),
        .testTarget(name: "IlliquidNativePlaybackTests", dependencies: ["IlliquidNativePlayback"]),
    ], swiftLanguageModes: [.v6])
