public enum ExecutorKind: String, Codable, Hashable, Sendable {
  case input
  case videoDecode
  case audioDecode
  case presentation
  case subtitle
  case persistence
  case platform
  case diagnostics
  case resource
  case mainActorControl
}

