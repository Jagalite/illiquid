# Linux historical-verifier failure diagnosis

The unchanged historical corpus reaches the single-period path `"."` at index
1 (its second input). The preceding empty-string input succeeds. On this Linux
Swift 6.3.3 runtime, `("." as NSString).deletingLastPathComponent` traps with
SIGILL in `String._startOfLastPathComponent.getter` inside `libFoundation.so`.

The focused probes reproduce the same failure in three independent processes:

- Foundation only, without importing or linking the application module;
- the mechanically renamed complete frozen recognition implementation;
- the candidate recognition implementation.

For all three probes, `""`, `"/"`, and `".."` succeed. The Foundation-only probe
flushes a marker immediately before calling `deletingLastPathComponent`; it
successfully reads `lastPathComponent` and `deletingPathExtension` first. The
baseline and candidate both fail during recognition, before any display-name
formatting is attempted. This isolates a pre-existing Foundation path-operation
failure in the measured Linux runtime, rather than a regression introduced by
the display-label change.

`diagnosis.json` records the environment, original artifact hashes, probe source
and binary hashes, and all 12 results. `commands.json` contains every build and
run command with exit status and stdout/stderr hashes. `logs/` retains the raw
output and crash backtraces. `run.py` reproduces this focused diagnosis against
the already-built verifier module; its source and original corpus were not
modified. Both probes were compiled with Swift 6 mode, optimization, and warnings
as errors. Execution ran outside the restricted sandbox to avoid a separate
libdispatch `/proc` access limitation.

The Linux historical equivalence check remains **failed**, not passed or
partially waived. The test corpus was not weakened. Native macOS historical
equivalence remains pending and must be reported independently.
