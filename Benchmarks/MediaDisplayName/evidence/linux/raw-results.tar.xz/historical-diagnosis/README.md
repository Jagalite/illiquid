# Focused historical-oracle diagnosis for PR #141

All three focused `"."` probes terminate with SIGILL in Linux Foundation's
`String._startOfLastPathComponent.getter`, called by
`NSString.deletingLastPathComponent.getter`:

| Probe | Exit code | Observation |
| --- | --- | --- |
| Foundation only | -4 | Logs successful `lastPathComponent` and `deletingPathExtension`, then traps while evaluating `deletingLastPathComponent` |
| Frozen historical baseline | -4 | Traps during filename recognition before a recognized result is returned |
| Exact PR #141 candidate | -4 | Traps at the same Foundation path-decomposition operation before the display-name getter is reached |

The candidate source SHA-256 is `cc3c1ac628498798384c3e93973ffa0dcd6f21036b1f1de779cd54c82cc944d1`,
from measured commit `c15703fcab7d7ccca3642eac626dad4923fb4fd9`. The recognition probe was newly
compiled against the current historical verifier's module at
`/tmp/media-display-name-pr141-20261028/historical-oracle/build/verifier/libMediaRecognition.so`
(SHA-256 `6f19e4eb9ec5d5507d1cdab56a51dc51c8bf6231bf49e09796c000498f3da8b2`). It does not link the previous candidate's
module. The two probe source files are byte-for-byte copies of the earlier focused
probes. Only the dot-path input was executed in this cohort; no broad test run or
other path probes were repeated.

The toolchain is Swift 6.3.3 on Linux x86_64. The three probes ran outside the tool
filesystem sandbox. The independent Foundation-only reproduction identifies this
failure as a Linux Foundation path-handling problem that also affects the frozen
baseline; it is not evidence of a regression caused by the display-name change.
These probes do not identify the library's internal defect beyond the failing
operation and stack location, or establish behavior on macOS.

**The complete historical equivalence gate remains failed.** No source, frozen
baseline, or corpus cases were changed or excluded to turn it green. This focused
diagnosis does not substitute for a completed native historical-equivalence run.

## Retained evidence

- Original full-gate failure: `../historical-oracle/logs/equivalence.stderr.txt`
- Probe sources: `FoundationProbe.swift` and `RecognizerProbe.swift`
- Probe runner: `run.py`
- Exact compile/run commands, return codes, and log hashes: `commands.json`
- Source, compiler, Foundation, binary, module, and original-artifact hashes: `diagnosis.json`
- Foundation-only output: `logs/dot-foundation-only.stdout.txt` and `.stderr.txt`
- Frozen-baseline output: `logs/dot-frozen-baseline.stdout.txt` and `.stderr.txt`
- Exact-candidate output: `logs/dot-candidate.stdout.txt` and `.stderr.txt`
