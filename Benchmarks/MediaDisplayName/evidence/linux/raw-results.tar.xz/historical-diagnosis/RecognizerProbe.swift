import Foundation
import MediaRecognition

func emit(_ text: String) {
    FileHandle.standardOutput.write(Data((text + "\n").utf8))
}

let variant = CommandLine.arguments[1]
let path = CommandLine.arguments[2]
emit("variant=" + variant + " input=" + String(reflecting: path))
if variant == "frozen-baseline" {
    let result = BaselineMediaNameRecognition.recognize(relativePath: path)
    emit("completed kind=" + result.kind.rawValue + " display=" + String(reflecting: result.displayName))
} else {
    precondition(variant == "candidate")
    let result = MediaNameRecognition.recognize(relativePath: path)
    emit("completed kind=" + result.kind.rawValue + " display=" + String(reflecting: result.displayName))
}
