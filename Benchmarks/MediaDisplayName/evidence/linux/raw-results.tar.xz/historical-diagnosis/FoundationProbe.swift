import Foundation

func emit(_ text: String) {
    FileHandle.standardOutput.write(Data((text + "\n").utf8))
}

let value = CommandLine.arguments[1] as NSString
emit("input=" + String(reflecting: value as String))
emit("lastPathComponent=" + String(reflecting: value.lastPathComponent))
emit("deletingPathExtension=" + String(reflecting: (value.lastPathComponent as NSString).deletingPathExtension))
emit("before deletingLastPathComponent")
emit("deletingLastPathComponent=" + String(reflecting: value.deletingLastPathComponent))
emit("completed")
