#!/usr/bin/env python3
"""Diagnose only the historical corpus's dot-path crash for the exact PR #141 module."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import subprocess

HERE = Path(__file__).resolve().parent
ORACLE = HERE.parent / "historical-oracle"
MODULE = ORACLE / "build/verifier"
SWIFTC = Path("/tmp/illiquid-cleanup-toolchain/toolchain/usr/bin/swiftc")
FOUNDATION = SWIFTC.parent.parent / "lib/swift/linux/libFoundation.so"
ENV = dict(os.environ, LD_LIBRARY_PATH="/tmp/illiquid-cleanup-toolchain/dependencies/usr/lib/x86_64-linux-gnu")
EXPECTED_CANDIDATE = "cc3c1ac628498798384c3e93973ffa0dcd6f21036b1f1de779cd54c82cc944d1"
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
(HERE / "logs").mkdir(exist_ok=True)
(HERE / "module-cache").mkdir(exist_ok=True)
commands = []


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def command(label, args):
    args = list(map(str, args))
    result = subprocess.run(args, cwd=HERE, env=ENV, capture_output=True, timeout=60)
    stdout = HERE / "logs" / (label + ".stdout.txt")
    stderr = HERE / "logs" / (label + ".stderr.txt")
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    commands.append(dict(label=label, arguments=args, returncode=result.returncode,
                         stdout=str(stdout.relative_to(HERE)), stderr=str(stderr.relative_to(HERE)),
                         stdout_sha256=sha(stdout), stderr_sha256=sha(stderr)))
    (HERE / "commands.json").write_text(json.dumps(commands, indent=2) + "\n")
    return result


assert sha(ORACLE / "sources/candidate.swift") == EXPECTED_CANDIDATE
catalog = json.loads((ORACLE / "logs/catalog.stdout.txt").read_text())
assert catalog["verification_paths"][1] == "."
module_before = sha(MODULE / "libMediaRecognition.so")
flags = ["-swift-version", "6", "-O", "-warnings-as-errors", "-module-cache-path", HERE / "module-cache"]
for name in ["FoundationProbe", "RecognizerProbe"]:
    extra = [] if name == "FoundationProbe" else [
        "-I", MODULE, "-L", MODULE, "-lMediaRecognition",
        "-Xlinker", "-rpath", "-Xlinker", MODULE]
    result = command("build-" + name, [SWIFTC, *flags, *extra, HERE / (name + ".swift"), "-o", HERE / name])
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors="replace"))

results = []
for variant in ["foundation-only", "frozen-baseline", "candidate"]:
    args = [HERE / "FoundationProbe", "."] if variant == "foundation-only" else [HERE / "RecognizerProbe", variant, "."]
    result = command("dot-" + variant, args)
    stderr = result.stderr.decode(errors="replace")
    results.append(dict(corpus_index=1, path=".", variant=variant,
                        returncode=result.returncode,
                        stdout=result.stdout.decode(errors="replace"),
                        foundation_start_of_last_path_component_trap="String._startOfLastPathComponent.getter" in stderr,
                        foundation_deleting_last_path_component_stack="NSString.deletingLastPathComponent.getter" in stderr))

assert sha(MODULE / "libMediaRecognition.so") == module_before
tracked = ["FoundationProbe.swift", "RecognizerProbe.swift", "run.py", "FoundationProbe", "RecognizerProbe", "commands.json"]
originals = ["manifest.json", "commands.jsonl", "sources/baseline.swift", "sources/candidate.swift",
             "sources/oracle.swift", "sources/Harness.swift", "logs/catalog.stdout.txt",
             "logs/equivalence.stdout.txt", "logs/equivalence.stderr.txt",
             "build/verifier/libMediaRecognition.so", "build/verifier/MediaRecognition.swiftmodule"]
manifest = json.loads((ORACLE / "manifest.json").read_text())
receipt = dict(timestamp_utc=datetime.now(timezone.utc).isoformat(), system=platform.platform(),
               measured_head="c15703fcab7d7ccca3642eac626dad4923fb4fd9",
               candidate_source_sha256=EXPECTED_CANDIDATE,
               swift_version=manifest["compiler"],
               environment_overrides={"LD_LIBRARY_PATH": ENV["LD_LIBRARY_PATH"]},
               launch_context="Executed outside the tool filesystem sandbox; focused diagnosis, no timings",
               source_and_binary_sha256={name: sha(HERE / name) for name in tracked},
               compiler_sha256=sha(SWIFTC),
               compiler_frontend_sha256=sha(SWIFTC.parent / "swift-frontend"),
               foundation_path=str(FOUNDATION), foundation_sha256=sha(FOUNDATION),
               linked_module_path=str(MODULE / "libMediaRecognition.so"),
               linked_module_sha256=module_before,
               original_artifacts={name: sha(ORACLE / name) for name in originals},
               results=results,
               same_failure_reproduced_in_all_three=all(x["returncode"] == -4 and x["foundation_start_of_last_path_component_trap"] and x["foundation_deleting_last_path_component_stack"] for x in results),
               interpretation="Focused dot-path diagnosis only. The exact current candidate, frozen baseline, and Foundation-only probe fail in Foundation path decomposition before displayName is reached. No production, frozen baseline, or corpus cases were edited. Linux historical equivalence remains failed; this diagnosis does not make that gate pass. Native macOS historical equivalence is not established by these Linux probes.")
(HERE / "diagnosis.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"same_failure_reproduced_in_all_three": receipt["same_failure_reproduced_in_all_three"], "results": results}, indent=2))
