#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / 'historical-oracle'
SWIFTC = '/tmp/illiquid-cleanup-toolchain/toolchain/usr/bin/swiftc'
ENV = dict(os.environ, LD_LIBRARY_PATH='/tmp/illiquid-cleanup-toolchain/dependencies/usr/lib/x86_64-linux-gnu')
MODULE = PRIOR / 'build/verifier'
(HERE / 'logs').mkdir(exist_ok=True)
commands = []

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def command(label, args):
    result = subprocess.run(args, cwd=HERE, env=ENV, capture_output=True)
    stdout = HERE / 'logs' / (label + '.stdout.txt')
    stderr = HERE / 'logs' / (label + '.stderr.txt')
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    record = dict(label=label, arguments=list(map(str, args)), returncode=result.returncode,
                  stdout=str(stdout.relative_to(HERE)), stderr=str(stderr.relative_to(HERE)),
                  stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
    commands.append(record)
    (HERE / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    return result

flags = ['-swift-version', '6', '-O', '-warnings-as-errors']
for name in ['FoundationProbe', 'RecognizerProbe']:
    extra = [] if name == 'FoundationProbe' else [
        '-I', str(MODULE), '-L', str(MODULE), '-lMediaRecognition',
        '-Xlinker', '-rpath', '-Xlinker', str(MODULE)]
    result = command('build-' + name, [SWIFTC, *flags, *extra,
        str(HERE / (name + '.swift')), '-o', str(HERE / name)])
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace'))

catalog = json.loads((PRIOR / 'logs/catalog.stdout.txt').read_text())
paths = catalog['verification_paths'][:4]
results = []
for index, path in enumerate(paths):
    for variant in ['foundation-only', 'frozen-baseline', 'candidate']:
        args = [str(HERE / 'FoundationProbe'), path] if variant == 'foundation-only' else [
            str(HERE / 'RecognizerProbe'), variant, path]
        result = command(f'path-{index}-{variant}', args)
        results.append(dict(corpus_index=index, path=path, variant=variant,
                            returncode=result.returncode,
                            stdout=result.stdout.decode(errors='replace'),
                            foundation_start_of_last_path_component_trap=
                                b'String._startOfLastPathComponent.getter' in result.stderr))

version = command('compiler-version', [SWIFTC, '--version'])
tracked = ['FoundationProbe.swift', 'RecognizerProbe.swift', 'run.py', 'FoundationProbe', 'RecognizerProbe']
receipt = dict(timestamp_utc=datetime.now(timezone.utc).isoformat(), system=platform.platform(),
    swift_version=version.stdout.decode(), environment_overrides={'LD_LIBRARY_PATH':ENV['LD_LIBRARY_PATH']},
    source_and_binary_sha256={name:sha(HERE/name) for name in tracked},
    original_artifacts={str(p.relative_to(PRIOR)):sha(p) for p in [
        PRIOR/'sources/baseline.swift', PRIOR/'sources/candidate.swift', PRIOR/'sources/oracle.swift',
        PRIOR/'sources/Harness.swift', PRIOR/'logs/catalog.stdout.txt',
        PRIOR/'logs/equivalence.stderr.txt', MODULE/'libMediaRecognition.so']},
    results=results,
    interpretation='Focused diagnosis only; no production, frozen baseline, or original corpus edits. Linux historical equivalence remains failed. Native macOS equivalence remains pending.')
(HERE/'diagnosis.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'results':results}, indent=2))
