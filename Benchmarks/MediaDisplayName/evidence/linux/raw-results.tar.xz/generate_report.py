#!/usr/bin/env python3
"""Render the adopted-PR-141 report from its completed cohort, never old tables."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/illiquid-episode-display-20261028')
COHORT = Path(__file__).resolve().parent
CANDIDATE = 'c15703fcab7d7ccca3642eac626dad4923fb4fd9'
PRODUCTION = 'cc3c1ac628498798384c3e93973ffa0dcd6f21036b1f1de779cd54c82cc944d1'
BASE_PR_HEAD = '5166cb73475b24dfb29f7115a5fa109e74379ba3'
OLD_COMMIT = '46f5384474e08bd04d6b20b5ab7a13adacdb01bf'

def read(path):
    return json.loads(path.read_text())

def pct(value):
    return f'{value:.2f}%'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audits-passed', action='store_true')
    parser.add_argument('--historical-status', choices=['failed', 'pending'], default='pending')
    parser.add_argument('--output', type=Path,
                        default=ROOT/'Documentation/MEDIA_DISPLAY_NAME_PERFORMANCE.md')
    args = parser.parse_args()
    component = read(COHORT/'component/summary.json')
    rows = read(COHORT/'projection/summary.json')
    tests = read(COHORT/'component/tests.json')
    differential = read(COHORT/'component/differential.json')
    manifest = read(COHORT/'component/manifest.json')
    environment = read(COHORT/'projection/environment.json')
    verification = read(COHORT/'projection/verification.json')
    assert manifest['head'] == environment['head'] == CANDIDATE
    assert hashlib.sha256((ROOT/'Sources/IlliquidCore/MediaLibrary/MediaNameRecognition.swift').read_bytes()).hexdigest() == PRODUCTION
    assert tests['passed'] and len(tests['runs']) == 4
    assert all(t['passed'] and t['tests_executed'] == 47 for t in tests['runs'])
    assert differential['passed'] and differential['cases'] == 5767
    assert differential['archives']['baseline'] == differential['archives']['candidate']
    assert component['measurements'] == 220 and len(component['cases']) == 11
    assert len(rows) == len(verification) == 10
    assert all(v['complete_output_equal'] for v in verification)
    assert all(row['pairs'] == 10 for row in rows)
    for name in ['component', 'projection']:
        assert read(COHORT/(name+'-invocation.json'))['returncode'] == 0

    cases = {row['case']: row for row in component['cases']}
    target_names = ['cached-numbered', 'cached-ranges', 'cached-wide-numbers', 'cached-unicode-titles']
    targeted = [cases[name] for name in target_names]
    target_medians = [case['paired_reduction_percent']['median'] for case in targeted]
    assert all(case['candidate_faster_pairs'] == 10 for case in targeted), 'Reassess the headline; not all targeted pairs favor the adopted candidate.'
    primary_min = min(case['paired_reduction_percent']['min'] for case in targeted)
    component_table = '\n'.join(
        '| `{}` | {:,.2f} | {:,.2f} | {:.2f}% | {:.2f}% | {}/{} |'.format(
            row['case'], row['ns_per_operation']['baseline']['median'],
            row['ns_per_operation']['candidate']['median'], row['paired_reduction_percent']['median'],
            row['process_cpu']['paired_reduction_percent']['median'], row['candidate_faster_pairs'], row['pairs'])
        for row in component['cases'])
    row_table = '\n'.join(
        '| `{}` | {:,} | {:.3f} | {:.3f} | {:.2f}% | {:.2f}% | {}/{} |'.format(
            row['case'], row['size'], row['baseline']['median_ns_per_projection']/1e6,
            row['candidate']['median_ns_per_projection']/1e6, row['median_paired_reduction_percent'],
            row['median_cpu_paired_reduction_percent'], sum(v > 0 for v in row['paired_reduction_percent']), row['pairs'])
        for row in rows)
    unchanged = [cases[name] for name in ['cached-dated-control','cached-movie-control','cached-unknown-control']]
    control_range = [row['paired_reduction_percent']['median'] for row in unchanged]
    recognition = [row for row in component['cases'] if row['case'].startswith('recognize-')]
    recognition_worst = min(recognition, key=lambda row: row['paired_reduction_percent']['min'])
    recognition_worst_value = recognition_worst['paired_reduction_percent']['min']
    recognition_caution = (
        f"The least favorable recognition-inclusive pair is `{recognition_worst['case']}` at **{pct(abs(recognition_worst_value))} slower** in the candidate."
        if recognition_worst_value < 0 else
        f"Even though all recorded recognition-inclusive pairs favor the candidate, the study uses one shared host and synthetic paths.")
    row_controls = [row for row in rows if row['case'] in ['movies_control','cached_projection_control']]
    control_medians = [row['median_paired_reduction_percent'] for row in row_controls]
    control_comment = (f"The movie and cached-projection control medians span **{pct(min(control_medians))} to {pct(max(control_medians))}**; "
                       "their individual pairs vary in both directions. These small control changes do not establish a systematic improvement or regression.")
    precomputed = [row for row in rows if row['case'] == 'precomputed_episodes']
    row_support = 'The precomputed-episode cases have favorable wall medians: ' + '; '.join(
        f"{pct(row['median_paired_reduction_percent'])} at {row['size']:,} files ({sum(v > 0 for v in row['paired_reduction_percent'])}/10 favorable pairs)"
        for row in precomputed) + '.'
    worst_row = min(rows, key=lambda row: min(row['paired_reduction_percent']))
    worst_row_value = min(worst_row['paired_reduction_percent'])
    row_outlier = (
        f"The least favorable individual row pair is `{worst_row['case']}` at {worst_row['size']:,} files, **{pct(-worst_row_value)} slower**."
        if worst_row_value < 0 else 'All recorded row pairs favor the candidate in this cohort.')
    audit_sentence = ('Independent audits reproduce both summaries from raw observations and verify the retained source and process-log receipts.'
                      if args.audits_passed else 'Independent receipt audits remain pending; the raw observations and runner summaries are retained.')
    audit_status = 'Passed for both experiments' if args.audits_passed else 'Pending'
    if args.historical_status == 'failed':
        errors = (COHORT/'historical-oracle/logs/equivalence.stderr.txt').read_text()
        assert 'String._startOfLastPathComponent' in errors
        historical_text = '''The intact historical comparison was rerun for the adopted candidate and
remains **failed on Linux**. Its second input is bare `"."`, which traps in this
Linux Foundation runtime's `NSString.deletingLastPathComponent` before recognition
returns. Focused probes retained with this cohort reproduce the same trap in a
Foundation-only executable, the frozen baseline, and the adopted #141 candidate.
The probes bind the result to the current compiled module and preserve their
commands, hashes, and raw failure logs. This is a recorded runtime limitation,
not a passed equivalence check. No input or frozen source was removed to conceal
it.'''
        historical_status = 'Failed on the pre-existing Foundation bare-dot path trap'
    else:
        historical_text = '''A rerun of the intact historical comparison for the adopted candidate is
pending. The earlier Linux attempt failed on its second input, bare `"."`, in
Foundation's `NSString.deletingLastPathComponent`. A Foundation-only probe and
the frozen baseline reproduce that trap independently of display formatting.
That diagnosis is retained in the prior evidence; it does not constitute a
completed equivalence run for the adopted candidate. No input or frozen source
has been removed to conceal the limitation.'''
        historical_status = 'Current rerun pending; prior Foundation bare-dot failure retained'

    report = f'''# Qualification of PR #141's episode display-name formatting

## Result and scope of this follow-up

This study qualifies the exact production implementation in
[PR #141](https://github.com/Jagalite/illiquid/pull/141). The stacked
[follow-up #233](https://github.com/Jagalite/illiquid/pull/233) has **zero changes
under `Sources/` relative to #141**. Its contributions are additional compatibility
tests, fresh independent measurements with complete receipts, surrounding-row
controls, and repair of the historical recognition verifier described below.

On the measured Linux host, #141's implementation reduces median paired time
for four numbered-episode label workloads by **{pct(min(target_medians))}–{pct(max(target_medians))}**.
The candidate is faster in all **40 of 40** targeted pairs; even the least
favorable targeted pair reduces time by **{pct(primary_min)}**. The tables report
wall and process CPU measurements separately. The supported conclusion is lower
label-construction cost on this host. It is not a whole-player speedup claim.

**Native macOS qualification remains pending.** The follow-up stays a draft until
the native benchmark, intact historical comparison, and application build/tests
complete. Linux timings do not establish macOS, SwiftUI, playback, or interactive
latency improvements. Complete row results remain exploratory, with all controls
and adverse observations disclosed.

The current [component summary](../Benchmarks/MediaDisplayName/evidence/linux/component-summary.json),
[row summary](../Benchmarks/MediaDisplayName/evidence/linux/projection-summary.json),
and [archive/provenance guide](../Benchmarks/MediaDisplayName/evidence/linux/README.md)
contain this fresh cohort. {audit_sentence}

## Why the historical verifier needs this follow-up

The historical runner in #141 shares the candidate's `RecognizedMediaName` type
with its frozen parser. It therefore requires that type's entire declaration to
remain byte-identical to the frozen declaration. Changing `displayName` violates
that requirement: the native workflow's existing **Compare exact metadata on pull
requests** step would reject staging with `RecognizedMediaName changed; the
shared-type oracle requires review`, before any comparison executes.

This follow-up preserves the complete frozen source and mechanically renames
both its result type and parser. The harness serializes each version's stored
fields and its own derived `seriesTitle`, `displayName`, and `section` values.
Baseline formatting is therefore evaluated independently. Simply dropping the
old declaration check while sharing today's result type would apply the new
formatter to both sides and could mask a regression.

The frozen historical file, manifest hash, and corpus remain unchanged. Receipts
record identifier-renaming counts and exact compiled inputs. This repairs the
gate's ability to validate #141; it does not declare that the native gate has
already passed. See the [verifier guide](../Benchmarks/MediaNameRecognition/README.md).

## Adopted implementation and application call site

PR #141's [`RecognizedMediaName.displayName`](../Sources/IlliquidCore/MediaLibrary/MediaNameRecognition.swift)
uses direct decimal strings when season, episode, and any range endpoint are
all between zero and **`Int32.max` (2,147,483,647)**. Values below ten receive a
leading zero. If any component is negative or wider, it evaluates the **complete
original Foundation expression**, including the original optional range formatter.
This preserves signed C `%d` conversion rather than changing unusual metadata
hints to unrestricted Swift integer formatting.

Nil numeric fields still become zero. A nonnil air date, including an empty
string, bypasses numeric formatting. Range/title separators, empty titles,
Unicode bytes, and movie/extra/unknown labels retain their behavior. The adopted
implementation adds no cache or mutable shared state.

The real path starts in
[`SourcesSidebar.synchronizeRecursiveMediaScan`](../Sources/IlliquidApp/UI/SourcesSidebar.swift):
`SourceRecursiveMediaLoader` obtains recognized metadata through
[`MediaSidecarReader`](../Sources/IlliquidCore/MediaLibrary/MediaSidecarReader.swift),
then `refreshVisibleRows` invokes the
[`SourceBrowserFilter`](../Sources/IlliquidApp/UI/SourceBrowserFilter.swift) actor.
When its tree input changes,
[`SourceTreeProjectionInput.rows` / `makeFlatFileRows`](../Sources/IlliquidApp/UI/SourceTreeProjectionInput.swift)
constructs each label and stores it in the row.

Normal metadata scans already supply recognition, so formatting remains real
work during the later reconstruction. Search or visibility edits that reuse
`cachedRows` reuse those strings. Filesystem discovery, sidecar I/O, drawing, and
playback are outside the changed operation and the measured intervals.

## Baseline, provenance, and measurement

| Item | Recorded value |
| --- | --- |
| Frozen main baseline | `ea2ff568237e2667f7b1aeee67b11a44ebe95b72` |
| Measured follow-up commit | `{CANDIDATE}` |
| Adopted #141 production commit | `{BASE_PR_HEAD}` |
| Recognition source SHA-256 | `{PRODUCTION}` |
| Runtime | Swift 6.3.3 release, Ubuntu 24.04.3 x86_64, Linux 6.18.55 |
| Host/affinity | Reported AMD EPYC 9V74, nine logical CPUs available, inherited CPU affinity `[8]` |

The host is shared; affinity does not create an isolated physical machine.
Kyoto was unavailable. Builds ran serially in isolated output directories, and
the fresh cohort ran outside the sandbox from its first invocation. The component
and row measurements did not overlap. The toolchain archive has verified release
signature and digest provenance in the evidence.

Each variant is an optimized production shared library called by a separately
compiled common driver, using `-O -whole-module-optimization` without cross-module
optimization. This prevents fixture specialization across the module boundary;
the exact application's optimizer context can still differ. Fixtures, warmup,
full JSON encoding, and validation occur outside timing. Label intervals include
small byte-count and bounded result-array handling; no empty loop is subtracted.

Each case uses ten fresh-process pairs, five AB and five BA, with equal iteration
counts for both variants. Calibration targets at least 100 ms for the faster
variant, and label workload order rotates between pairs. Pilots are retained
separately. All **220 label/recognition observations** and **200 row observations**
are included, without outlier removal. Wall time uses `DispatchTime`; process CPU
uses `CLOCK_PROCESS_CPUTIME_ID`.

Positive percentages below mean less time. They are medians of the ten paired
`100 × (1 − candidate / baseline)` reductions. Absolute medians are calculated
independently, so their ratio need not reproduce the paired percentage. These
descriptive medians are not population-level confidence or significance claims.

## Label and recognition results

Times are nanoseconds per operation, with 128 inputs per batch. `cached-*` means
already recognized metadata, not a previously formatted label. `recognize-*`
includes complete filename recognition before display formatting.

| Workload | Baseline ns | Candidate ns | Paired wall reduction | Paired CPU reduction | Faster pairs |
| --- | ---: | ---: | ---: | ---: | ---: |
{component_table}

The consistent reduction belongs to the four ordinary numbered-label cases.
Dated, movie, and unknown controls retain their formatting paths; their paired
wall medians range from **{pct(min(control_range))} to {pct(max(control_range))}**.
The `cached-unbounded-control` fixture uses cyclic unusual integer triples.
Every triple contains a negative or above-`Int32.max` component, so the adopted
candidate takes the complete original Foundation expression on every record.
The new bounds guard is still included in its measured cost.

Recognition-inclusive timings are a broader operation and support a less direct
conclusion than isolated label construction. {recognition_caution}
Every observation remains in the receipts. The current report confines its
primary performance claim to the targeted label workloads.

## Complete media-row results

The row study compiles twelve real production files or guarded verbatim model
declarations. Only the focal recognition file differs between baseline and
candidate. It measures complete `input.rows()` calls with production default
sorting: creation date descending, name/type sorting off. Timed work includes
path processing, sorting, context labels, display strings, and row allocation.
The previous result stays alive until its replacement returns. Directory
enumeration, sidecar reads, file opening, SwiftUI, and playback are excluded.

Times are milliseconds per reconstruction or cached actor projection for the
stated number of input files.

| Workload | Files | Baseline ms | Candidate ms | Paired wall reduction | Paired CPU reduction | Faster pairs |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
{row_table}

{row_support}

{control_comment} {row_outlier}

The row results support a benefit in these synthetic reconstruction cases, with
variation that limits broader predictions. They do not establish a generally
faster media browser. The cache control uses a real `SourceBrowserFilter` actor; its
tree and visibility build counters remain at one through repeated unchanged-input
projections. That confirms labels are reused on this path. Native and live-app
measurements remain necessary before assigning a user-visible latency benefit.

## Correctness and qualification status

Baseline and candidate each pass **47 tests in five suites in debug and release**,
for four completed invocations. The suites combine the three existing recognition
suites, #141's eight episode-formatting tests, and seven follow-up tests. They
exhaust all values from zero through 9,999 in each numeric role—a subset of the
nonnegative `Int32` fast path—and include 4,096 deterministic positive-`Int32`
samples, signed/overflow boundaries, nils, date precedence, exact title bytes,
non-episode kinds, and public metadata-hint application.

Both variants produce **5,767 byte-identical complete differential records**.
All ten complete row/projection trace pairs match, including metadata, UTF-8
bytes, IDs, order, visibility, and projection outputs. Every timed process checks
its complete final result outside the clock.

{historical_text}

| Qualification | Current status |
| --- | --- |
| Focused Linux tests | Passed: four invocations, 47 tests each, five suites |
| Focused label differential | Passed: 5,767 complete records |
| Row/projection differential | Passed: ten cases and all final timed outputs |
| Portable GitHub correctness on the measured commit | Passed |
| Independent receipt audits | {audit_status} |
| Historical Linux comparison | {historical_status} |
| Native macOS measurements and intact historical comparison | Pending |
| Native application graph build and affected tests | Pending |
| Live UI or playback qualification | Not performed |

The [portable correctness job](https://github.com/Jagalite/illiquid/actions/runs/40756021516/job/123055027201)
passed on the measured commit, including the focused tests and complete label/row
comparisons. The [workflow](../.github/workflows/media-display-name.yml) provides pinned Swift
6.3.3 portable correctness, native macOS measurements with the intact historical
corpus, and a separate native application build/test job. Consult the draft PR's
current checks; queued jobs are not completed qualification.

## Earlier candidate and reproduction

An independent formatter was researched before reconciling this work with #141.
Its [report](https://github.com/Jagalite/illiquid/blob/{OLD_COMMIT}/Documentation/MEDIA_DISPLAY_NAME_PERFORMANCE.md)
and [complete evidence](https://github.com/Jagalite/illiquid/tree/{OLD_COMMIT}/Benchmarks/MediaDisplayName/evidence/linux)
remain available at the immutable earlier commit. That candidate used different
production bytes and a narrower fast path. Adopting #141 therefore required the
fresh tests and measurements reported here; **none of the earlier candidate's
timings enters these tables**.

The earlier investigation's sandbox/libdispatch test failure and successful
retry belong to that earlier cohort, not this clean outside-sandbox rerun. An
even earlier exploratory screen lost its raw receipts during a session reset;
its numbers are used in neither retained result set.

Use fresh output directories and follow `AGENTS.md` to submit builds through
Kyoto when available. Select a Swift toolchain through `PATH` or the runners'
documented overrides:

```sh
python3 Benchmarks/MediaDisplayName/run.py \\
  --pairs 10 --target-ms 100 --output /tmp/media-display-name-new
python3 Benchmarks/MediaDisplayNameProjection/run.py \\
  --pairs 10 --target-ms 100 --output /tmp/media-display-projection-new
# Native macOS: retain the complete historical filename corpus.
python3 Benchmarks/MediaNameRecognition/run.py \\
  --verify-only --output /tmp/media-display-historical-new
```

The [label](../Benchmarks/MediaDisplayName/README.md) and
[row](../Benchmarks/MediaDisplayNameProjection/README.md) guides define measurement
boundaries and outputs. The retained archive contains raw observations, pilots,
commands, source snapshots, full traces, test/build logs, environment/toolchain
provenance, and audits. Compiled products and caches are omitted; binary hashes
and build commands remain. The [evidence receipt](../Benchmarks/MediaDisplayName/evidence/linux/receipt.json)
records the archive digest and source match. Final narrative/evidence edits do
not change the measured production, tests, or benchmark executables' inputs.
'''
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(report)
    print(json.dumps({'output': str(args.output), 'words': len(report.split()),
                      'candidate': CANDIDATE, 'tables': 'fresh adopted-PR-141 cohort only',
                      'audits_passed': args.audits_passed, 'historical_status': args.historical_status}))

if __name__ == '__main__':
    main()
