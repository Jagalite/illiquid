// swift-tools-version: 6.1
import PackageDescription
let package = Package(
    name: "MediaDisplayNameQualification", platforms: [.macOS("26.0")],
    targets: [
        .target(name: "IlliquidCore"),
        .testTarget(name: "IlliquidCoreTests", dependencies: ["IlliquidCore"]),
    ]
)
