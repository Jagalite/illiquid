import Foundation
import IlliquidCore

struct SourceTabItem: Codable, Equatable, Hashable, Sendable {
    enum Kind: String, Codable, Sendable {
        case file
        case folder
    }

    let kind: Kind
    let path: String

    init(kind: Kind, url: URL) {
        self.kind = kind
        path = (
            NormalizedFileURL.normalize(url) ?? url.absoluteURL.standardized
        ).path
    }

    var url: URL {
        URL(fileURLWithPath: path, isDirectory: kind == .folder)
    }
}

enum SourceVisibilityViewMode: String, Codable, CaseIterable, Sendable {
    case tree
    case filesOnly
    case foldersOnly
    case media

    var scansRecursively: Bool { self == .filesOnly || self == .media }

    var title: String {
        switch self {
        case .tree:
            "Tree"
        case .filesOnly:
            "Files Only"
        case .foldersOnly:
            "Folders Only"
        case .media:
            "Media"
        }
    }

    var systemImage: String {
        switch self {
        case .tree:
            "list.bullet.indent"
        case .filesOnly:
            "doc"
        case .foldersOnly:
            "folder"
        case .media:
            "film.stack"
        }
    }
}

struct SourceVisibilityRegexRule: Codable, Equatable, Identifiable, Sendable {
    static let colorCount = 6

    let id: String
    let pattern: String
    let colorIndex: Int
    var isEnabled: Bool

    static func isValid(pattern: String) -> Bool {
        !pattern.isEmpty
            && pattern.count <= 512
            && (try? NSRegularExpression(pattern: pattern)) != nil
    }

    static func nextColorIndex(
        after rules: [SourceVisibilityRegexRule]
    ) -> Int {
        guard let last = rules.last else { return 0 }
        return (last.colorIndex + 1) % colorCount
    }
}

struct SourceVisibilityConfiguration: Codable, Equatable, Sendable {
    static let `default` = Self(
        viewMode: .tree,
        showsHiddenItems: false,
        manuallyHiddenPaths: [],
        alwaysShownPaths: [],
        regexRules: []
    )

    var viewMode: SourceVisibilityViewMode
    var showsHiddenItems: Bool
    var manuallyHiddenPaths: Set<String>
    var alwaysShownPaths: Set<String>
    var regexRules: [SourceVisibilityRegexRule]

    var isDefault: Bool {
        self == .default
    }

    mutating func normalize() {
        manuallyHiddenPaths = SourceVisibilityPath.normalized(
            manuallyHiddenPaths
        )
        alwaysShownPaths = SourceVisibilityPath.normalized(alwaysShownPaths)
        alwaysShownPaths.subtract(manuallyHiddenPaths)

        var seenIDs: Set<String> = []
        var seenPatterns: Set<String> = []
        regexRules = regexRules.compactMap { rule in
            let pattern = rule.pattern.trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            guard !rule.id.isEmpty,
                  seenIDs.insert(rule.id).inserted,
                  seenPatterns.insert(pattern).inserted,
                  SourceVisibilityRegexRule.isValid(pattern: pattern)
            else {
                return nil
            }
            return SourceVisibilityRegexRule(
                id: rule.id,
                pattern: pattern,
                colorIndex: min(
                    max(rule.colorIndex, 0),
                    SourceVisibilityRegexRule.colorCount - 1
                ),
                isEnabled: rule.isEnabled
            )
        }
    }
}

enum SourceVisibilityPath {
    static func normalized(_ url: URL) -> String? {
        guard url.isFileURL else { return nil }
        return (NormalizedFileURL.normalize(url) ?? url.absoluteURL.standardized).path
    }

    static func normalized(_ paths: Set<String>) -> Set<String> {
        Set(paths.compactMap { path in
            guard path.hasPrefix("/") else { return nil }
            return normalized(URL(fileURLWithPath: path, isDirectory: false))
        })
    }
}

struct SourceTreeEntry: Equatable, Sendable {
    enum Kind: Equatable, Sendable {
        case folder
        case media
    }

    let url: URL
    let kind: Kind
    let dateAdded: Date?
    let creationDate: Date?
    let visibilityPath: String?
    var recognizedMedia: RecognizedMediaName? = nil

    init(
        url: URL,
        kind: Kind,
        dateAdded: Date?,
        creationDate: Date?,
        visibilityPath: String? = nil
    ) {
        self.url = url
        self.kind = kind
        self.dateAdded = dateAdded
        self.creationDate = creationDate
        self.visibilityPath = visibilityPath
    }
}

struct SourceVisibilityRegexMatch: Equatable, Sendable {
    let id: String
    let colorIndex: Int
}

enum SourceVisibilityHideMatch: Equatable, Sendable {
    case manual
    case noMedia
    case regex(SourceVisibilityRegexMatch)
}

struct SourceVisibilityEvaluation: Equatable, Sendable {
    let hiddenMatches: [SourceVisibilityHideMatch]
    let regexMatches: [SourceVisibilityRegexMatch]
}

struct SourceRowVisibility: Equatable, Sendable {
    let matches: [SourceVisibilityHideMatch]
    let isInherited: Bool

    var regexMatches: [SourceVisibilityRegexMatch] {
        matches.compactMap { match in
            guard case let .regex(regexMatch) = match else { return nil }
            return regexMatch
        }
    }

    var isManual: Bool {
        matches.contains(.manual)
    }
}

struct SourceVisibilityMatcher {
    private struct CompiledRule {
        let match: SourceVisibilityRegexMatch
        let expression: NSRegularExpression
    }

    private let configuration: SourceVisibilityConfiguration
    private let rootPaths: [String]
    private let compiledRules: [CompiledRule]
    private let rootEvaluations: [String: SourceVisibilityEvaluation]

    init(
        configuration: SourceVisibilityConfiguration,
        roots: [URL]
    ) {
        self.configuration = configuration
        let rootPaths = roots.compactMap(SourceVisibilityPath.normalized)
        let compiledRules: [CompiledRule] =
            configuration.regexRules.compactMap { rule in
            guard rule.isEnabled,
                  let expression = try? NSRegularExpression(pattern: rule.pattern)
            else {
                return nil
            }
            return CompiledRule(
                match: SourceVisibilityRegexMatch(
                    id: rule.id,
                    colorIndex: rule.colorIndex
                ),
                expression: expression
            )
        }
        self.rootPaths = rootPaths
        self.compiledRules = compiledRules
        rootEvaluations = Dictionary(uniqueKeysWithValues: rootPaths.map { path in
            (
                path,
                Self.evaluate(
                    normalizedPath: path,
                    candidate: URL(fileURLWithPath: path, isDirectory: false).lastPathComponent,
                    configuration: configuration,
                    compiledRules: compiledRules
                )
            )
        })
    }

    func evaluate(_ url: URL) -> SourceVisibilityEvaluation {
        guard let normalizedPath = SourceVisibilityPath.normalized(url)
        else {
            return SourceVisibilityEvaluation(
                hiddenMatches: [],
                regexMatches: []
            )
        }
        return evaluate(normalizedPath: normalizedPath)
    }

    func evaluate(
        normalizedPath: String
    ) -> SourceVisibilityEvaluation {
        Self.evaluate(
            normalizedPath: normalizedPath,
            candidate: relativePath(normalizedPath: normalizedPath),
            configuration: configuration,
            compiledRules: compiledRules
        )
    }

    private static func evaluate(
        normalizedPath: String,
        candidate: String,
        configuration: SourceVisibilityConfiguration,
        compiledRules: [CompiledRule]
    ) -> SourceVisibilityEvaluation {
        let range = NSRange(candidate.startIndex..., in: candidate)
        let regexMatches = compiledRules.compactMap { rule in
            var matched = false
            rule.expression.enumerateMatches(in: candidate, options: [.reportProgress], range: range) {
                result, _, stop in
                if result != nil { matched = true }
                if matched || Task.isCancelled { stop.pointee = true }
            }
            return matched ? rule.match : nil
        }

        if configuration.manuallyHiddenPaths.contains(normalizedPath) {
            return SourceVisibilityEvaluation(
                hiddenMatches: [.manual] + regexMatches.map {
                    .regex($0)
                },
                regexMatches: regexMatches
            )
        }
        if configuration.alwaysShownPaths.contains(normalizedPath) {
            return SourceVisibilityEvaluation(
                hiddenMatches: [],
                regexMatches: regexMatches
            )
        }
        return SourceVisibilityEvaluation(
            hiddenMatches: regexMatches.map { .regex($0) },
            regexMatches: regexMatches
        )
    }

    func evaluateIncludingAncestors(_ url: URL) -> SourceVisibilityEvaluation {
        guard let normalizedPath = SourceVisibilityPath.normalized(url) else {
            return SourceVisibilityEvaluation(
                hiddenMatches: [],
                regexMatches: []
            )
        }
        return evaluateIncludingAncestors(normalizedPath: normalizedPath)
    }

    func evaluateIncludingAncestors(
        normalizedPath: String
    ) -> SourceVisibilityEvaluation {
        guard let rootPath = matchingRootPath(for: normalizedPath) else {
            return evaluate(normalizedPath: normalizedPath)
        }
        return evaluateIncludingAncestors(
            normalizedPath: normalizedPath,
            rootPath: rootPath
        )
    }

    private func evaluateIncludingAncestors(
        normalizedPath: String,
        rootPath: String
    ) -> SourceVisibilityEvaluation {
        let direct = evaluate(normalizedPath: normalizedPath)

        var regexMatches = direct.regexMatches
        var ancestorPath = URL(fileURLWithPath: normalizedPath, isDirectory: false)
            .deletingLastPathComponent()
            .path
        while ancestorPath.count >= rootPath.count,
              ancestorPath == rootPath
                || ancestorPath.hasPrefix(rootPath + "/")
        {
            let ancestor = ancestorPath == rootPath
                ? rootEvaluations[rootPath] ?? evaluate(
                    normalizedPath: ancestorPath
                )
                : evaluate(normalizedPath: ancestorPath)
            for match in ancestor.regexMatches where !regexMatches.contains(match) {
                regexMatches.append(match)
            }
            if !ancestor.hiddenMatches.isEmpty {
                return SourceVisibilityEvaluation(
                    hiddenMatches: ancestor.hiddenMatches,
                    regexMatches: regexMatches
                )
            }
            if ancestorPath == rootPath {
                break
            }
            ancestorPath = URL(fileURLWithPath: ancestorPath, isDirectory: false)
                .deletingLastPathComponent()
                .path
        }

        return SourceVisibilityEvaluation(
            hiddenMatches: direct.hiddenMatches,
            regexMatches: regexMatches
        )
    }

    func relativePath(for url: URL) -> String {
        guard let normalizedPath = SourceVisibilityPath.normalized(url)
        else {
            return url.lastPathComponent
        }
        return relativePath(normalizedPath: normalizedPath)
    }

    func relativePath(normalizedPath: String) -> String {
        let matchingRoot = matchingRootPath(for: normalizedPath)

        guard let matchingRoot else {
            return URL(fileURLWithPath: normalizedPath, isDirectory: false).lastPathComponent
        }
        guard normalizedPath != matchingRoot else {
            return URL(fileURLWithPath: matchingRoot, isDirectory: false).lastPathComponent
        }
        return String(normalizedPath.dropFirst(matchingRoot.count + 1))
    }

    private func matchingRootPath(for normalizedPath: String) -> String? {
        rootPaths
            .filter { rootPath in
                normalizedPath == rootPath
                    || normalizedPath.hasPrefix(rootPath + "/")
            }
            .max { $0.count < $1.count }
    }
}

enum SourceVisibilityProjection {
    static func includes(
        _ kind: SourceTreeEntry.Kind?,
        in viewMode: SourceVisibilityViewMode
    ) -> Bool {
        guard let kind else { return true }
        return switch (viewMode, kind) {
        case (.tree, _), (.filesOnly, .media), (.media, .media), (.foldersOnly, .folder):
            true
        case (.filesOnly, .folder), (.media, .folder), (.foldersOnly, .media):
            false
        }
    }
}

enum SourceTreeSortCriterion: String, CaseIterable, Identifiable, Sendable {
    case type
    case dateCreated
    case name

    var id: String { rawValue }

    var title: String {
        switch self {
        case .type:
            "Type"
        case .dateCreated:
            "Date Created"
        case .name:
            "Name"
        }
    }

    var systemImage: String {
        switch self {
        case .type:
            "square.grid.2x2"
        case .dateCreated:
            "calendar"
        case .name:
            "textformat"
        }
    }
}

enum SourceTreeSortDirection: String, CaseIterable, Sendable {
    case off
    case ascending
    case descending

    var next: Self {
        switch self {
        case .off:
            .ascending
        case .ascending:
            .descending
        case .descending:
            .off
        }
    }

    var title: String {
        switch self {
        case .off:
            "Off"
        case .ascending:
            "Ascending"
        case .descending:
            "Descending"
        }
    }

    var systemImage: String? {
        switch self {
        case .off:
            nil
        case .ascending:
            "arrow.up"
        case .descending:
            "arrow.down"
        }
    }

    static func resolve(_ rawValue: String) -> Self {
        Self(rawValue: rawValue) ?? .off
    }
}

struct SourceTreeSortConfiguration: Equatable, Sendable {
    let name: SourceTreeSortDirection
    let dateCreated: SourceTreeSortDirection
    let type: SourceTreeSortDirection

    func direction(
        for criterion: SourceTreeSortCriterion
    ) -> SourceTreeSortDirection {
        switch criterion {
        case .type:
            type
        case .dateCreated:
            dateCreated
        case .name:
            name
        }
    }
}

enum SourceTreeSorting {
    private static let criterionPrecedence: [SourceTreeSortCriterion] = [
        .type,
        .dateCreated,
        .name,
    ]

    static func sorted(
        _ entries: [SourceTreeEntry],
        using configuration: SourceTreeSortConfiguration
    ) -> [SourceTreeEntry] {
        entries
            .enumerated()
            .sorted { left, right in
                for criterion in criterionPrecedence {
                    let direction = configuration.direction(for: criterion)
                    guard direction != .off else { continue }
                    if let precedes = orderedBefore(
                        left.element,
                        right.element,
                        by: criterion,
                        direction: direction
                    ) {
                        return precedes
                    }
                }
                return left.offset < right.offset
            }
            .map(\.element)
    }

    private static func orderedBefore(
        _ left: SourceTreeEntry,
        _ right: SourceTreeEntry,
        by criterion: SourceTreeSortCriterion,
        direction: SourceTreeSortDirection
    ) -> Bool? {
        switch criterion {
        case .type:
            guard left.kind != right.kind else { return nil }
            let foldersFirst = direction == .ascending
            return foldersFirst
                ? left.kind == .folder
                : left.kind == .media

        case .dateCreated:
            switch (left.creationDate, right.creationDate) {
            case let (leftDate?, rightDate?) where leftDate != rightDate:
                return direction == .ascending
                    ? leftDate < rightDate
                    : leftDate > rightDate
            case (_?, nil):
                return true
            case (nil, _?):
                return false
            default:
                return nil
            }

        case .name:
            let comparison = naturalComparison(left.url, right.url)
            guard comparison != .orderedSame else { return nil }
            return direction == .ascending
                ? comparison == .orderedAscending
                : comparison == .orderedDescending
        }
    }

    private static func naturalComparison(
        _ left: URL,
        _ right: URL
    ) -> ComparisonResult {
        let nameComparison = left.lastPathComponent.localizedStandardCompare(
            right.lastPathComponent
        )
        guard nameComparison == .orderedSame else { return nameComparison }
        return left.path.compare(right.path, options: [.literal])
    }
}

struct SourceTreeDisplayRow: Identifiable, Equatable, Sendable {
    enum Kind: Equatable, Sendable {
        case folder(isRoot: Bool)
        case media(dateAdded: Date?)
        case message(String)
        case mediaSection

        var itemKind: SourceTreeEntry.Kind? {
            switch self {
            case .folder:
                .folder
            case .media:
                .media
            case .message, .mediaSection:
                nil
            }
        }
    }

    let id: String
    let folderID: String
    let url: URL
    let displayName: String
    var contextLabel: String? = nil
    var recognizedMedia: RecognizedMediaName? = nil
    var visibilityPath: String? = nil
    let depth: Int
    let ancestorIDs: [String]
    let kind: Kind
    var visibility: SourceRowVisibility? = nil
    var containsSupportedMedia: Bool? = nil
}

enum SourceTreeIdentity {
    static func folderID(for url: URL) -> String {
        normalizedPath(for: url)
    }

    static func fileID(for url: URL) -> String {
        normalizedPath(for: url)
    }

    static func path(fromFolderID id: String) -> String {
        id
    }

    static func isFolderID(_ id: String, inside root: URL) -> Bool {
        let rootPath = normalizedPath(for: root)
        return id == rootPath || id.hasPrefix(rootPath + "/")
    }

    private static func normalizedPath(for url: URL) -> String {
        (NormalizedFileURL.normalize(url) ?? url.absoluteURL.standardized).path
    }
}

