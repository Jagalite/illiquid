import Foundation
enum BaselineSourceBrowserSearch {
    static func search(_ rows: [SourceTreeDisplayRow], query: String) -> [SourceTreeDisplayRow] {
        let query = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return rows }
        let matchingRows = rows.filter {
            guard !Task.isCancelled else { return false }
            switch $0.kind {
            case .folder, .media:
                if $0.displayName.localizedCaseInsensitiveContains(query) { return true }
                guard let media = $0.recognizedMedia else { return false }
                return $0.url.lastPathComponent.localizedCaseInsensitiveContains(query)
                    || media.section.localizedCaseInsensitiveContains(query)
                    || media.catalogIDs.contains { $0.localizedCaseInsensitiveContains(query) }
                    || ($0.contextLabel?.localizedCaseInsensitiveContains(query) ?? false)
            case .message, .mediaSection:
                return false
            }
        }
        let visibleIDs = Set(matchingRows.flatMap { [$0.id] + $0.ancestorIDs })
        return rows.filter { visibleIDs.contains($0.id) }
    }
}
