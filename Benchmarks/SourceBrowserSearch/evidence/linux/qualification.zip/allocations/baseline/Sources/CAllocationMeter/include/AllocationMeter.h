#include <stdint.h>
void meter_begin(void);
void meter_end(void);
uint64_t meter_requests(void);
uint64_t meter_bytes(void);
