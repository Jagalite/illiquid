// swift-tools-version: 6.1
import PackageDescription
let package = Package(
    name: "SourceSearchQualification",
    platforms: [.macOS("26.0")],
    products: [.executable(name: "SearchBenchmark", targets: ["SearchBenchmark"])],
    targets: [
        .target(name: "IlliquidCore"),
        .target(name: "IlliquidApp", dependencies: ["IlliquidCore"]),
        .target(name: "CAllocationMeter"),
        .executableTarget(name: "SearchBenchmark", dependencies: ["IlliquidApp", "IlliquidCore", "CAllocationMeter"]),
    ]
)
