// swift-tools-version: 6.1
import PackageDescription
let package = Package(
    name: "EpisodeDisplayNameQualification",
    platforms: [.macOS("26.0")],
    products: [.executable(name: "EpisodeDisplayNameProbe", targets: ["EpisodeDisplayNameDriver"])],
    targets: [
        .target(name: "IlliquidCore", swiftSettings: [.unsafeFlags(["-enable-testing"])]),
        .executableTarget(name: "EpisodeDisplayNameDriver", dependencies: ["IlliquidCore"]),
        .testTarget(name: "IlliquidCoreTests", dependencies: ["IlliquidCore"]),
    ]
)
