#!/usr/bin/env python3
"""Independent verification of the completed FileIdentityKeys Linux campaign."""
import hashlib
import json
import math
import random
import statistics
import subprocess
from pathlib import Path

OUT = Path('/tmp/illiquid-file-key-linux-final')
REPO = Path('/workspace/scratch/a0c3dcf9529d/illiquid')


def read(name):
    return json.loads((OUT / name).read_text())


def hashes(data):
    return {
        'sha256': hashlib.sha256(data).hexdigest(),
        'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
    }


def equal_number(left, right):
    assert math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-8), (left, right)


manifest = read('manifest.json')
summary = read('summary.json')
commands = read('commands.json')
receipts = read('receipts.json')
calibrations = read('calibrations.json')
schedule = read('schedule.json')
differential = read('differential.json')
rows = [json.loads(line) for line in (OUT / 'observations.jsonl').read_text().splitlines()]
assert manifest['status'] == 'complete'
assert summary['complete'] is True
assert summary['pairs'] == 12
assert summary['baseline_target_cpu_ms'] == 250
assert differential == summary['differential']
assert differential['mismatches'] == 0 and differential['examples'] == []
assert differential['cases'] == 75220 and differential['nativeReferenceCases'] == 0
assert len(receipts) == 17 and len(rows) == 408
assert not (OUT / 'failure.json').exists()

command_by_label = {}
for expected_id, command in enumerate(commands):
    assert command['id'] == expected_id and command['returncode'] == 0
    assert command['completed_utc'] >= command['started_utc']
    assert (OUT / command['stdout']).exists() and (OUT / command['stderr']).exists()
    assert command['label'] not in command_by_label
    command_by_label[command['label']] = command

for variant in ['baseline', 'candidate']:
    compile_command = command_by_label['build-' + variant]['arguments']
    assert '-O' in compile_command and '-whole-module-optimization' in compile_command
    assert '-swift-version' in compile_command and '-emit-object' in compile_command
    assert '-cross-module-optimization' not in compile_command and '-Ounchecked' not in compile_command
    for name, original in manifest['baseline']['files'].items():
        snapshot = (OUT / 'sources' / variant / name).read_bytes()
        assert hashes(snapshot) == manifest['source_hashes'][variant][name]
        if variant == 'baseline':
            frozen = (REPO / 'Benchmarks/FileIdentityKeys/baseline' / name).read_bytes()
            assert snapshot == frozen
            baseline_git = subprocess.check_output([
                'git', '-C', str(REPO), 'show', manifest['baseline']['revision'] + ':' + original['source'],
            ])
            assert snapshot == baseline_git
            assert hashes(snapshot) == {key: original[key] for key in ['sha256', 'git_blob_sha1']}
        else:
            assert snapshot == (REPO / original['source']).read_bytes()
            if name != 'NormalizedFileURL.swift':
                assert snapshot == (OUT / 'sources/baseline' / name).read_bytes()

for name in ['Driver.swift', 'Differential.swift', 'run.py']:
    snapshot = (OUT / 'sources' / name).read_bytes()
    assert hashes(snapshot) == manifest['source_hashes'][name]
    assert snapshot == (REPO / 'Benchmarks/FileIdentityKeys' / name).read_bytes()

for name, expected_sha in manifest['binary_hashes'].items():
    assert hashlib.sha256((OUT / 'build' / name).read_bytes()).hexdigest() == expected_sha
for frontend in manifest['environment']['actual_swift_frontends']:
    digest = hashlib.sha256()
    with Path(frontend['path']).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    assert digest.hexdigest() == frontend['sha256']

driver_command = command_by_label['build-driver']['arguments']
assert '-O' in driver_command and '-cross-module-optimization' not in driver_command
assert sum(value.endswith('URLBaseline.o') for value in driver_command) == 1
assert sum(value.endswith('URLCandidate.o') for value in driver_command) == 1

expected_indices = {
    'playlist-empty': None,
    'playlist-single-hit': 0,
    'playlist-small-last': 7,
    'playlist-first-1000': 0,
    'playlist-middle-1000': 500,
    'playlist-last-1000': 999,
    'playlist-miss-1000': None,
    'playlist-unicode-last-256': 255,
    'playlist-rejected-query-256': None,
}
units = {}
checksums = {}
operation_counts = {}
for case, combined in receipts.items():
    assert combined['case'] == case
    assert combined['baseline'] == combined['candidate']
    command = command_by_label['receipt-' + case]
    assert json.loads((OUT / command['stdout']).read_text()) == combined
    value = combined['baseline']
    if case.startswith('keys'):
        assert len(value['keyBytes']) == len(value['urls'])
        assert all(key is None or all(isinstance(byte, int) and 0 <= byte <= 255 for byte in key)
                   for key in value['keyBytes'])
        checksums[case] = sum(len(key) if key is not None else 1 for key in value['keyBytes'])
        operation_counts[case] = len(value['urls'])
        units[case] = 'persistence key'
        if case == 'keys-tiny-ascii':
            assert [bytes(value) for value in value['keyBytes']] == [b'/', b'/a', b'/a.mkv']
        if case == 'keys-rejected-256':
            assert value['keyBytes'] == [None] * 256
    else:
        assert value['indices'] == [expected_indices[case]]
        expected_count = 0 if case == 'playlist-empty' else (
            1 if case == 'playlist-single-hit' else (
                8 if case == 'playlist-small-last' else (256 if case.endswith('256') else 1000)))
        assert len(value['items']) == expected_count
        checksums[case] = sum(index + 1 if index is not None else 0 for index in value['indices'])
        operation_counts[case] = len(value['queries'])
        units[case] = 'playlist lookup'

case_order = manifest['method']['cases']
assert set(case_order) == set(receipts) == set(summary['cases']) == set(calibrations)
assert len(schedule) == 12
expected_sequence = []
for pair_index, item in enumerate(schedule):
    assert item['pair'] == pair_index and set(item['cases']) == set(case_order)
    assert len(item['cases']) == len(case_order)
    order = ['baseline', 'candidate'] if pair_index % 2 == 0 else ['candidate', 'baseline']
    assert item['variants'] == order
    for case in item['cases']:
        for position, variant in enumerate(order):
            expected_sequence.append((pair_index, case, position, variant))
assert [(row['pair'], row['case'], row['position'], row['variant']) for row in rows] == expected_sequence

for row in rows:
    case = row['case']
    assert row['unit'] == units[case]
    assert row['operationsPerRound'] == operation_counts[case]
    assert row['operations'] == row['operationsPerRound'] * row['rounds']
    assert row['expectedChecksumPerRound'] == checksums[case]
    assert row['checksum'] == checksums[case] * row['rounds']
    assert row['wallNanoseconds'] > 0 and row['cpuNanoseconds'] > 0
    assert row['rounds'] == calibrations[case]['selected_rounds']
    command = commands[row['command_id']]
    assert command['label'] == f"measure-{row['pair']:02d}-{case}-{row['variant']}"
    emitted = json.loads((OUT / command['stdout']).read_text())
    assert emitted == {key: value for key, value in row.items()
                       if key not in ['pair', 'order', 'position', 'command_id']}

for case, value in calibrations.items():
    assert value['included_in_summary'] is False
    samples = value['samples']
    assert 1 <= len(samples) <= 8 and samples[0]['rounds'] == 1
    for attempt, sample in enumerate(samples):
        command = command_by_label[f'calibrate-{case}-{attempt}']
        assert json.loads((OUT / command['stdout']).read_text()) == sample
        assert sample['variant'] == 'baseline' and sample['case'] == case
    last = samples[-1]
    rounds = min(20_000_000, max(1, math.ceil(last['rounds'] * 250_000_000 / last['cpuNanoseconds'])))
    assert rounds == value['selected_rounds']

audited_cases = {}
for case_index, case in enumerate(case_order):
    records = [row for row in rows if row['case'] == case]
    assert len(records) == 24
    paired = []
    for index in range(12):
        pair = {row['variant']: row for row in records if row['pair'] == index}
        assert len(pair) == 2
        assert pair['baseline']['operations'] == pair['candidate']['operations']
        assert pair['baseline']['checksum'] == pair['candidate']['checksum']
        paired.append(pair)
    assert summary['cases'][case]['rounds'] == calibrations[case]['selected_rounds']
    assert summary['cases'][case]['operations_per_round'] == operation_counts[case]
    for label, timer in [('cpu', 'cpuNanoseconds'), ('wall', 'wallNanoseconds')]:
        before = [pair['baseline'][timer] / pair['baseline']['operations'] for pair in paired]
        after = [pair['candidate'][timer] / pair['candidate']['operations'] for pair in paired]
        ratios = [b / a for a, b in zip(before, after)]
        expected = summary['cases'][case][label]
        equal_number(expected['baseline_median_ns_per_operation'], statistics.median(before))
        equal_number(expected['candidate_median_ns_per_operation'], statistics.median(after))
        equal_number(expected['median_paired_change_percent'], (statistics.median(ratios) - 1) * 100)
        equal_number(expected['median_paired_delta_ns_per_operation'], statistics.median(b - a for a, b in zip(before, after)))
        assert expected['candidate_faster_pairs'] == sum(value < 1 for value in ratios)
        assert expected['pair_count'] == 12
        generator = random.Random(manifest['method']['seed'] + case_index)
        bootstrap = sorted(statistics.median(generator.choices(ratios, k=12)) for _ in range(5000))
        for actual, expected_percentile in zip(expected['median_change_bootstrap_95_percent'], [bootstrap[124], bootstrap[4874]]):
            equal_number(actual, (expected_percentile - 1) * 100)
    audited_cases[case] = summary['cases'][case]

report = {
    'passed': True,
    'baseline_revision': manifest['baseline']['revision'],
    'candidate_source_sha256': manifest['source_hashes']['candidate']['NormalizedFileURL.swift']['sha256'],
    'observations_verified': len(rows),
    'paired_comparisons_verified': len(rows) // 2,
    'workloads_verified': len(case_order),
    'exact_byte_differential': differential,
    'commands_verified': len(commands),
    'checks': [
        'Frozen source bytes equal the recorded Git revision and hashes',
        'Candidate source bytes equal captured sources and current checkout',
        'Unchanged support source bytes match exactly',
        'Compiler frontends, objects, executable hashes and non-CMO flags verified',
        'All complete baseline/candidate receipts equal, with independent expected positions',
        'All recorded process outputs agree with retained observations and checksum expectations',
        'Every fixed-work pair has equal operations and balanced AB/BA order',
        'Calibration work and selection verified and kept outside timing summaries',
        'Reported paired CPU/wall medians, absolute costs, wins and confidence intervals recomputed',
        'No observation deletion, missing output files, failed command or failure record',
    ],
    'round_capped_cases': [case for case, value in calibrations.items() if value['at_round_cap']],
    'screening': summary['screening'],
    'cases': audited_cases,
}
(OUT / 'independent-audit.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'cases'}, indent=2, sort_keys=True))
for case in case_order:
    value = audited_cases[case]['cpu']
    print(f"{case}: {value['median_paired_change_percent']:+.2f}% CPU; "
          f"{value['candidate_faster_pairs']}/12 faster; "
          f"{value['baseline_median_ns_per_operation']:.1f} -> {value['candidate_median_ns_per_operation']:.1f} ns; "
          f"95% bootstrap {value['median_change_bootstrap_95_percent']}")
