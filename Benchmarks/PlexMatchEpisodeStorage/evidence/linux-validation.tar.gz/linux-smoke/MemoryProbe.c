#include <malloc.h>
#include <stdint.h>
/* Linux smoke-only allocator-reported in-use storage; not the native metric. */
uint64_t plexmatch_heap_in_use(void) {
    struct mallinfo2 info = mallinfo2();
    return (uint64_t)info.uordblks + (uint64_t)info.hblkhd;
}
