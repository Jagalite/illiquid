// Corelibs Foundation has no Objective-C autorelease pool. Smoke-only shim.
@inline(__always)
func autoreleasepool<Result>(invoking body: () throws -> Result) rethrows -> Result {
    try body()
}
