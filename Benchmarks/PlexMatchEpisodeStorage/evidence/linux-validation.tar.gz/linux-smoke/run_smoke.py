#!/usr/bin/env python3
"""Adapted Linux smoke only; never a replacement for native macOS qualification."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PREPARED = Path('/tmp/plexmatch-shared-support-preflight/evidence')
ORIGINAL = Path('/tmp/plexmatch-storage-root-preflight/evidence')
TOOLCHAIN = Path('/tmp/illiquid-swift-toolchain/swift-6.3.2-RELEASE-ubuntu24.04/usr/bin')
NAMES = ['MediaNameRecognition', 'MediaMetadataHints', 'PlexMatchHints', 'NFOMetadataHints', 'MediaSidecarReader']
SCENARIOS = ['mappings-0', 'mappings-1024', 'near-128kib', 'reader-cache-32']


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    native_manifest = json.loads((PREPARED / 'manifest.json').read_text())
    original_manifest = json.loads((ORIGINAL / 'manifest.json').read_text())
    assert native_manifest['productionSHA256'] == original_manifest['productionSHA256']
    shutil.copyfile(PREPARED / 'manifest.json', ROOT / 'native-prepared-manifest.json')
    shutil.copyfile(ORIGINAL / 'manifest.json', ROOT / 'original-cohort-manifest.json')
    shutil.copytree(PREPARED / 'fixtures', ROOT / 'fixtures')
    native_hashes, adapted_hashes = {}, {}
    changes = []
    for variant in ('baseline', 'candidate'):
        native_hashes[variant], adapted_hashes[variant] = {}, {}
        (ROOT / 'native' / variant).mkdir(parents=True)
        (ROOT / 'adapted' / variant).mkdir(parents=True)
        for name in NAMES:
            relative = f'Sources/IlliquidCore/MediaLibrary/{name}.swift'
            native = ROOT / 'native' / variant / f'{name}.swift'
            shutil.copyfile(PREPARED / 'sources' / variant / relative, native)
            native_hashes[variant][relative] = digest(native)
            assert digest(native) == native_manifest['productionSHA256'][variant][relative]
            text = native.read_text()
            adapted = text
            if name == 'MediaSidecarReader':
                assert text.count('import Darwin\n') == 1
                adapted = text.replace('import Darwin\n', 'import Glibc\n', 1)
            elif name == 'NFOMetadataHints':
                assert text.count('import Foundation\n') == 1
                adapted = text.replace('import Foundation\n', 'import Foundation\nimport FoundationXML\n', 1)
            path = ROOT / 'adapted' / variant / f'{name}.swift'
            path.write_text(adapted)
            adapted_hashes[variant][relative] = digest(path)
            changes.extend(difflib.unified_diff(text.splitlines(keepends=True), adapted.splitlines(keepends=True),
                                              fromfile=f'native/{variant}/{name}.swift',
                                              tofile=f'adapted/{variant}/{name}.swift'))
    (ROOT / 'platform-adaptations.diff').write_text(''.join(changes))
    common = PREPARED / 'sources/common/Benchmarks/PlexMatchEpisodeStorage'
    shutil.copyfile(common / 'Harness.swift', ROOT / 'Harness.swift')
    shutil.copyfile(common / 'MemoryProbe.c', ROOT / 'native-MemoryProbe.c')
    shutil.copyfile(PREPARED / 'sources/common/MemoryProbe.h', ROOT / 'MemoryProbe.h')
    assert digest(ROOT / 'Harness.swift') == native_manifest['inputSHA256']['Benchmarks/PlexMatchEpisodeStorage/Harness.swift']
    (ROOT / 'LinuxAutoreleasePool.swift').write_text('''// Corelibs Foundation has no Objective-C autorelease pool. Smoke-only shim.
@inline(__always)
func autoreleasepool<Result>(invoking body: () throws -> Result) rethrows -> Result {
    try body()
}
''')
    (ROOT / 'MemoryProbe.c').write_text('''#include <malloc.h>
#include <stdint.h>
/* Linux smoke-only allocator-reported in-use storage; not the native metric. */
uint64_t plexmatch_heap_in_use(void) {
    struct mallinfo2 info = mallinfo2();
    return (uint64_t)info.uordblks + (uint64_t)info.hblkhd;
}
''')
    environment = dict(os.environ)
    environment['LD_LIBRARY_PATH'] = '/tmp/illiquid-swift-deps/usr/lib/x86_64-linux-gnu'
    environment['SWIFT_DETERMINISTIC_HASHING'] = '1'
    environment['CLANG_MODULE_CACHE_PATH'] = str(ROOT / 'module-cache')
    (ROOT / 'logs').mkdir()
    (ROOT / 'bin').mkdir()
    commands = []

    def run(argv, label, timeout=180):
        argv = [str(part) for part in argv]
        stdout, stderr = ROOT / 'logs' / (label + '.stdout.log'), ROOT / 'logs' / (label + '.stderr.log')
        record = {'label': label, 'argv': argv, 'cwd': str(ROOT)}
        started = time.monotonic()
        try:
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(argv, cwd=ROOT, env=environment, stdout=out, stderr=err, timeout=timeout)
            record['returncode'] = process.returncode
        except subprocess.TimeoutExpired:
            record['returncode'] = 'timeout'
        finally:
            record.update(elapsedSeconds=time.monotonic() - started,
                          stdout=str(stdout.relative_to(ROOT)), stderr=str(stderr.relative_to(ROOT)),
                          stdoutSHA256=digest(stdout), stderrSHA256=digest(stderr))
            commands.append(record)
            save('commands.json', commands)
        print(f"{label}: {record['returncode']} ({record['elapsedSeconds']:.2f}s)", flush=True)
        if record['returncode'] != 0:
            raise RuntimeError(f"{label} failed\n{stderr.read_text(errors='replace')[-6000:]}")
        return stdout.read_text()

    version = run([TOOLCHAIN / 'swift', '--version'], 'swift-version')
    manifest = {'qualification': 'adapted Linux smoke only; native macOS run required',
                'startedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'swiftVersion': version, 'environment': {key: environment[key] for key in
                    ['LD_LIBRARY_PATH', 'SWIFT_DETERMINISTIC_HASHING', 'CLANG_MODULE_CACHE_PATH']},
                'nativeProductionSHA256': native_hashes, 'adaptedProductionSHA256': adapted_hashes,
                'harnessSHA256': digest(ROOT / 'Harness.swift'),
                'nativeHarnessSHA256': native_manifest['inputSHA256']['Benchmarks/PlexMatchEpisodeStorage/Harness.swift'],
                'adaptationDiffSHA256': digest(ROOT / 'platform-adaptations.diff'),
                'shimSHA256': digest(ROOT / 'LinuxAutoreleasePool.swift'),
                'linuxProbeSHA256': digest(ROOT / 'MemoryProbe.c'),
                'nativeProbeSHA256': digest(ROOT / 'native-MemoryProbe.c'),
                'probeHeaderSHA256': digest(ROOT / 'MemoryProbe.h'),
                'tools': {name: {'path': str(TOOLCHAIN / name),
                                 'resolvedPath': str((TOOLCHAIN / name).resolve()),
                                 'sha256': digest((TOOLCHAIN / name).resolve())}
                          for name in ['swift', 'swiftc', 'clang']}}
    save('manifest.json', manifest)
    try:
        run([TOOLCHAIN / 'clang', '-O2', '-c', ROOT / 'MemoryProbe.c', '-o', ROOT / 'bin/MemoryProbe.o'], 'compile-probe')
        for variant in ('baseline', 'candidate'):
            run([TOOLCHAIN / 'swiftc', '-swift-version', '6', '-O', '-whole-module-optimization', '-parse-as-library',
                 '-module-name', 'PlexMatchEpisodeStorage', '-module-cache-path', ROOT / 'module-cache',
                 '-import-objc-header', ROOT / 'MemoryProbe.h',
                 *[ROOT / 'adapted' / variant / f'{name}.swift' for name in NAMES],
                 ROOT / 'Harness.swift', ROOT / 'LinuxAutoreleasePool.swift', ROOT / 'bin/MemoryProbe.o',
                 '-o', ROOT / 'bin' / variant], f'compile-{variant}')
        manifest['binarySHA256'] = {variant: digest(ROOT / 'bin' / variant) for variant in ['baseline', 'candidate']}
        manifest['probeObjectSHA256'] = digest(ROOT / 'bin/MemoryProbe.o')
        save('manifest.json', manifest)
        semantic = {}
        for variant in ('baseline', 'candidate'):
            raw = run([ROOT / 'bin' / variant, 'semantic', ROOT / 'fixtures/fixtures.json'], f'semantic-{variant}')
            (ROOT / f'semantic-{variant}.json').write_text(raw)
            semantic[variant] = json.loads(raw)
        assert semantic['baseline'] == semantic['candidate'], 'semantic output differs'
        samples = []
        with (ROOT / 'samples.jsonl').open('w') as sink:
            for scenario in SCENARIOS:
                pair = []
                for variant in ('baseline', 'candidate'):
                    raw = run([ROOT / 'bin' / variant, 'sample', ROOT / 'fixtures/fixtures.json', scenario, '10'],
                              f'sample-{scenario}-{variant}')
                    sample = json.loads(raw) | {'variant': variant, 'smokeOnly': True}
                    samples.append(sample)
                    pair.append(sample)
                    sink.write(json.dumps(sample, sort_keys=True) + '\n')
                    sink.flush()
                assert pair[0]['allocation']['payloadChecksum'] == pair[1]['allocation']['payloadChecksum']
        summary = {'status': 'passed', 'qualification': manifest['qualification'],
                   'nativeSourceHashesMatchOriginalCohort': True, 'nativeHarnessUnmodified': True,
                   'semanticParity': True,
                   'semanticSHA256': {variant: digest(ROOT / f'semantic-{variant}.json') for variant in semantic},
                   'sampleCount': len(samples), 'samples': samples,
                   'limitation': 'One adapted Linux sample per variant/scenario; no native result or statistical performance claim.'}
        save('summary.json', summary)
        print(json.dumps({'status': 'passed', 'semanticParity': True, 'sampleCount': len(samples)}), flush=True)
    except Exception as error:
        save('failure.json', {'type': type(error).__name__, 'message': str(error)})
        raise


if __name__ == '__main__':
    main()
