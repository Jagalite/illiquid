#include <stdint.h>
uint64_t plexmatch_heap_in_use(void);
