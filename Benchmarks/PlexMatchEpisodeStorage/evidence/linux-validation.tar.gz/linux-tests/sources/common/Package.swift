// swift-tools-version: 6.1
import PackageDescription
let package = Package(
    name: "PlexMatchLocalValidation",
    targets: [
        .target(name: "IlliquidCore"),
        .testTarget(name: "IlliquidCoreTests", dependencies: ["IlliquidCore"])
    ]
)
