#!/usr/bin/env python3
"""Isolated Linux syntax and behavior verification, not memory qualification."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import time

EVIDENCE = Path(__file__).resolve().parent
RUN = Path(json.loads((EVIDENCE / "paths.json").read_text())["run"])
REPO = Path("/workspace/scratch/c0180271e51f/illiquid")
BASELINE = "4abf4b44f13386ccd04f1ce4ad0e756255ca4d14"
CANDIDATE = "abe486456e4fd2b735a52a233ca50a41be08815c"
SWIFT = Path("/tmp/illiquid-swift-toolchain/swift-6.3.2-RELEASE-ubuntu24.04/usr/bin/swift")
DEPS = "/tmp/illiquid-swift-deps/usr/lib/x86_64-linux-gnu"
SOURCE_NAMES = ["MediaNameRecognition", "MediaMetadataHints", "PlexMatchHints"]
TEST = "Tests/IlliquidCoreTests/PlexMatchHintsRegressionTests.swift"
PACKAGE = '''// swift-tools-version: 6.1
import PackageDescription
let package = Package(
    name: "PlexMatchLocalValidation",
    targets: [
        .target(name: "IlliquidCore"),
        .testTarget(name: "IlliquidCoreTests", dependencies: ["IlliquidCore"])
    ]
)
'''


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def source(revision, name):
    return subprocess.run(["git", "show", f"{revision}:{name}"], cwd=REPO,
                          capture_output=True, check=True).stdout


def main():
    (EVIDENCE / "logs").mkdir()
    manifest = {
        "purpose": "Pure PlexMatch functional and compiler validation on Linux; no native macOS memory claims",
        "baselineRevision": BASELINE, "candidateRevision": CANDIDATE,
        "swift": str(SWIFT), "platform": platform.platform(), "sourceHashes": {},
        "kyotoPath": "/Volumes/seed1/Projects/kyoto/kyoto.py",
        "kyotoAvailable": Path("/Volumes/seed1/Projects/kyoto/kyoto.py").exists(),
        "startedAtUTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "packageManifest": PACKAGE, "packageManifestSHA256": sha(PACKAGE.encode()),
    }
    if manifest["kyotoAvailable"]:
        raise RuntimeError("Kyoto appeared; submit the recorded command through the queue")
    tests = source(CANDIDATE, TEST)
    if tests != (REPO / TEST).read_bytes():
        raise RuntimeError("Current tests differ from the requested candidate commit")
    candidate_sources = {}
    for name in SOURCE_NAMES:
        path = f"Sources/IlliquidCore/MediaLibrary/{name}.swift"
        raw = source(CANDIDATE, path)
        if raw != (REPO / path).read_bytes():
            raise RuntimeError(f"Current source differs from requested candidate: {path}")
        candidate_sources[name] = raw
        if name != "PlexMatchHints" and raw != source(BASELINE, path):
            raise RuntimeError(f"Unrelated support source differs between commits: {path}")
    for variant in ("baseline", "candidate"):
        package = RUN / "packages" / variant
        hashes = {}
        for name in SOURCE_NAMES:
            path = f"Sources/IlliquidCore/MediaLibrary/{name}.swift"
            raw = source(BASELINE, path) if variant == "baseline" and name == "PlexMatchHints" else candidate_sources[name]
            staged = package / "Sources" / "IlliquidCore" / f"{name}.swift"
            staged.parent.mkdir(parents=True, exist_ok=True)
            staged.write_bytes(raw)
            archived = EVIDENCE / "sources" / variant / path
            archived.parent.mkdir(parents=True, exist_ok=True)
            archived.write_bytes(raw)
            hashes[path] = {"sha256": sha(raw), "bytes": len(raw)}
        staged_test = package / TEST
        staged_test.parent.mkdir(parents=True, exist_ok=True)
        staged_test.write_bytes(tests)
        hashes[TEST] = {"sha256": sha(tests), "bytes": len(tests)}
        (package / "Package.swift").write_text(PACKAGE)
        manifest["sourceHashes"][variant] = hashes
    archived_test = EVIDENCE / "sources" / "common" / TEST
    archived_test.parent.mkdir(parents=True, exist_ok=True)
    archived_test.write_bytes(tests)
    (EVIDENCE / "sources" / "common" / "Package.swift").write_text(PACKAGE)
    environment = dict(os.environ)
    overrides = {
        "LD_LIBRARY_PATH": DEPS,
        "CLANG_MODULE_CACHE_PATH": str(RUN / "cache" / "clang"),
        "SWIFTPM_MODULECACHE_OVERRIDE": str(RUN / "cache" / "swift-modules"),
        "XDG_CACHE_HOME": str(RUN / "cache" / "xdg"),
    }
    environment.update(overrides)
    manifest["environmentOverrides"] = overrides
    save("manifest.json", manifest)
    records, results = [], []

    def execute(label, command):
        command = list(map(str, command))
        stdout = EVIDENCE / "logs" / (label + ".stdout.log")
        stderr = EVIDENCE / "logs" / (label + ".stderr.log")
        start = time.monotonic()
        with stdout.open("wb") as out, stderr.open("wb") as err:
            process = subprocess.run(command, cwd=RUN, env=environment, stdout=out,
                                     stderr=err, timeout=300)
        record = {"label": label, "command": command, "cwd": str(RUN),
                  "returncode": process.returncode, "elapsedSeconds": time.monotonic() - start,
                  "stdout": str(stdout.relative_to(EVIDENCE)), "stderr": str(stderr.relative_to(EVIDENCE)),
                  "stdoutSHA256": sha(stdout.read_bytes()), "stderrSHA256": sha(stderr.read_bytes())}
        records.append(record)
        save("commands.json", records)
        print(f"{label}: exit {process.returncode}, {record['elapsedSeconds']:.2f}s", flush=True)
        if process.returncode:
            print(stderr.read_text(errors="replace")[-7000:], flush=True)
            print(stdout.read_text(errors="replace")[-3000:], flush=True)
            raise RuntimeError(f"{label} failed; see recorded logs")
        return stdout.read_text(errors="replace") + stderr.read_text(errors="replace")

    try:
        manifest["toolchainVersion"] = execute("swift-version", [SWIFT, "--version"]).strip()
        save("manifest.json", manifest)
        for variant in ("baseline", "candidate"):
            package = RUN / "packages" / variant
            for configuration in ("debug", "release"):
                label = f"tests-{variant}-{configuration}"
                logs = execute(label, [SWIFT, "test", "--package-path", package,
                    "--scratch-path", RUN / "build" / variant,
                    "--cache-path", RUN / "cache" / "swiftpm",
                    "--config-path", RUN / "config" / "swiftpm",
                    "--security-path", RUN / "security" / "swiftpm",
                    "--jobs", "2", "--no-parallel", "-c", configuration])
                counts = re.findall(r"Test run with (\d+) tests?\b[^\n]*\bpassed\b", logs)
                if not counts or int(counts[-1]) <= 0:
                    raise RuntimeError(f"{label} did not report a nonempty successful Swift Testing run")
                results.append({"variant": variant, "configuration": configuration,
                                "passedTests": int(counts[-1]), "logLabel": label})
                save("tests.json", results)
                print(f"{label}: {results[-1]['passedTests']} tests passed", flush=True)
        if len(results) != 4 or len({r["passedTests"] for r in results}) != 1:
            raise RuntimeError("The four configurations did not report the same nonzero test count")
        summary = {"status": "passed", "scope": manifest["purpose"], "runs": results,
                   "equalNonzeroTestCounts": True, "testCountPerRun": results[0]["passedTests"],
                   "baselineRevision": BASELINE, "candidateRevision": CANDIDATE,
                   "completedAtUTC": datetime.datetime.now(datetime.timezone.utc).isoformat()}
        save("summary.json", summary)
        print(json.dumps(summary, indent=2), flush=True)
    except Exception as error:
        save("failure.json", {"error": str(error), "type": type(error).__name__, "completedRuns": results})
        raise


if __name__ == "__main__":
    main()
