#!/usr/bin/env python3
"""Balanced repeated Linux study using the unchanged, previously qualified binaries."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'evidence'
SMOKE = Path('/tmp/plexmatch-linux-smoke-c018')
PREPARED = Path('/tmp/plexmatch-shared-support-preflight/evidence')
TESTS = Path('/workspace/scratch/c0180271e51f/plexmatch-local-validation-c018-ts6l1nph')
PAIRS = 6
TARGET_MS = 100
ARCHIVE = {
    'repositoryPath': 'Benchmarks/PlexMatchEpisodeStorage/evidence/linux-validation.tar.gz',
    'commitPrefix': '814b0990',
    'sha256': '84c2f05cae5f345778b0473befe3d4157527aa7719012a0ff95d9e9e54485585',
    'contents': 'Pure-source tests plus original adapted Linux smoke and complete semantic output'
}


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def save(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def inputs():
    files = []
    for directory in ['native', 'adapted', 'fixtures', 'bin']:
        files.extend(path for path in (SMOKE / directory).rglob('*') if path.is_file())
    files.extend(SMOKE / name for name in ['Harness.swift', 'LinuxAutoreleasePool.swift', 'MemoryProbe.c',
                 'MemoryProbe.h', 'native-MemoryProbe.c', 'platform-adaptations.diff',
                 'semantic-baseline.json', 'semantic-candidate.json', 'manifest.json', 'run_smoke.py'])
    return {str(path.relative_to(SMOKE)): digest(path) for path in sorted(files)}


def main():
    EVIDENCE.mkdir()
    (EVIDENCE / 'logs').mkdir()
    original_manifest = json.loads((SMOKE / 'manifest.json').read_text())
    original_summary = json.loads((SMOKE / 'summary.json').read_text())
    prepared_manifest = json.loads((PREPARED / 'manifest.json').read_text())
    fixtures = json.loads((SMOKE / 'fixtures/fixtures.json').read_text())
    before = inputs()
    for variant in ['baseline', 'candidate']:
        assert before[f'bin/{variant}'] == original_manifest['binarySHA256'][variant]
        assert before[f'semantic-{variant}.json'] == original_summary['semanticSHA256'][variant]
        for name, expected in original_manifest['nativeProductionSHA256'][variant].items():
            assert before[f'native/{variant}/{Path(name).name}'] == expected
        for name, expected in original_manifest['adaptedProductionSHA256'][variant].items():
            assert before[f'adapted/{variant}/{Path(name).name}'] == expected
    assert before['Harness.swift'] == original_manifest['nativeHarnessSHA256']
    assert original_summary['semanticParity'] and original_summary['status'] == 'passed'
    for name, expected in prepared_manifest['fixtureSHA256'].items():
        assert before[f'fixtures/{name}'] == expected
    assert fixtures['cache']['totalInputBytes'] < 16 * 1024 * 1024
    assert all(fixture['inputBytes'] <= 128 * 1024 for fixture in fixtures['cases'])
    tests_manifest = json.loads((TESTS / 'manifest.json').read_text())
    tests = json.loads((TESTS / 'tests.json').read_text())
    assert len(tests) == 4 and all(test['passedTests'] == 14 for test in tests)
    assert {(test['variant'], test['configuration']) for test in tests} == {
        (variant, configuration) for variant in ['baseline', 'candidate'] for configuration in ['debug', 'release']}
    for variant in ['baseline', 'candidate']:
        for name, info in tests_manifest['sourceHashes'][variant].items():
            if name.startswith('Sources/'):
                assert original_manifest['nativeProductionSHA256'][variant][name] == info['sha256']
    for name in ['summary.json', 'tests.json', 'manifest.json', 'commands.json']:
        shutil.copyfile(TESTS / name, EVIDENCE / ('pure-tests-' + name))
    shutil.copyfile(SMOKE / 'manifest.json', EVIDENCE / 'smoke-manifest.json')
    shutil.copyfile(SMOKE / 'platform-adaptations.diff', EVIDENCE / 'platform-adaptations.diff')
    shutil.copyfile(SMOKE / 'fixtures/fixtures.json', EVIDENCE / 'fixtures.json')
    helper = PREPARED / 'sources/common/Benchmarks/PlexMatchEpisodeStorage/runner.py'
    shutil.copyfile(helper, EVIDENCE / 'summary-helper.py')
    spec = importlib.util.spec_from_file_location('qualified_summary_helper', EVIDENCE / 'summary-helper.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    environment = dict(os.environ)
    environment.update(original_manifest['environment'])
    manifest = {
        'qualification': 'Repeated adapted Linux component study; native macOS qualification is separate',
        'startedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'platform': platform.platform(), 'pythonVersion': sys.version,
        'pairs': PAIRS, 'targetMilliseconds': TARGET_MS, 'freshProcesses': 72,
        'order': 'AB / BA alternation by pair, six scenarios per pair, serial processes',
        'environmentOverrides': original_manifest['environment'],
        'inputRoot': str(SMOKE), 'inputSHA256Before': before,
        'nativeProductionSHA256': original_manifest['nativeProductionSHA256'],
        'adaptedProductionSHA256': original_manifest['adaptedProductionSHA256'],
        'binarySHA256': original_manifest['binarySHA256'],
        'semanticSHA256': original_summary['semanticSHA256'],
        'semanticParity': 'Complete prior output matched, with identical binary and fixture hashes verified here',
        'priorEvidenceArchive': ARCHIVE,
        'summaryHelperSHA256': digest(EVIDENCE / 'summary-helper.py'),
        'cohortScriptSHA256': digest(Path(__file__)),
        'pureTests': {'scope': tests_manifest['purpose'], 'reportedTestsPerRun': 14,
                      'runs': tests, 'manifestSHA256': digest(TESTS / 'manifest.json'),
                      'testsSHA256': digest(TESTS / 'tests.json')}
    }
    save('manifest.json', manifest)
    save('parity.json', {'equal': True, 'binaryAndFixtureHashesMatchPriorSmoke': True,
                         'semanticSHA256': original_summary['semanticSHA256'], 'priorEvidenceArchive': ARCHIVE})
    records, samples = [], []
    try:
        with (EVIDENCE / 'samples.jsonl').open('w') as sink:
            for pair in range(PAIRS):
                order = ['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']
                for fixture in fixtures['cases'] + [fixtures['cache']]:
                    for position, variant in enumerate(order):
                        label = f"pair-{pair:02}-{fixture['id']}-{variant}"
                        stdout, stderr = EVIDENCE / 'logs' / (label + '.stdout.log'), EVIDENCE / 'logs' / (label + '.stderr.log')
                        argv = [str(SMOKE / 'bin' / variant), 'sample', str(SMOKE / 'fixtures/fixtures.json'),
                                fixture['id'], str(TARGET_MS)]
                        record = {'label': label, 'argv': argv, 'cwd': str(ROOT),
                                  'pair': pair, 'position': position, 'variant': variant}
                        started = time.monotonic()
                        try:
                            with stdout.open('wb') as out, stderr.open('wb') as err:
                                process = subprocess.run(argv, cwd=ROOT, env=environment, stdout=out, stderr=err, timeout=180)
                            record['returncode'] = process.returncode
                        except subprocess.TimeoutExpired:
                            record['returncode'] = 'timeout'
                        finally:
                            record.update(elapsedSeconds=time.monotonic() - started,
                                          stdout=str(stdout.relative_to(EVIDENCE)), stderr=str(stderr.relative_to(EVIDENCE)),
                                          stdoutSHA256=digest(stdout), stderrSHA256=digest(stderr))
                            records.append(record)
                            save('commands.json', records)
                        if record['returncode'] != 0:
                            raise RuntimeError(f"{label} failed ({record['returncode']}): {stderr.read_text(errors='replace')[-4000:]}")
                        sample = json.loads(stdout.read_text()) | {'pair': pair, 'position': position, 'variant': variant}
                        assert sample['scenario'] == fixture['id']
                        assert sample['inputBytes'] == fixture.get('inputBytes', fixture.get('totalInputBytes'))
                        if fixture['id'] == fixtures['cache']['id']:
                            assert sample['filesRead'] == 32 and sample['secondPassAdditionalReads'] == 0
                        samples.append(sample)
                        sink.write(json.dumps(sample, sort_keys=True) + '\n')
                        sink.flush()
                print(f"Completed pair {pair + 1}/{PAIRS}: {' / '.join(order)}; {len(samples)} fresh processes", flush=True)
        after = inputs()
        manifest['inputSHA256After'] = after
        manifest['inputHashesUnchanged'] = before == after
        manifest['completedAtUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save('manifest.json', manifest)
        assert before == after, 'an input changed during the cohort'
        summary = module.summarize(samples, fixtures, SimpleNamespace(pairs=PAIRS, target_ms=TARGET_MS))
        summary['qualification'] = manifest['qualification']
        summary['memoryMetric'] = 'Linux glibc mallinfo2().uordblks + hblkhd: held minus after explicit payload release; allocator caches may remain counted'
        summary['tests'] = manifest['pureTests']
        summary['nativeMacOSQualification'] = 'Not performed by this study; separate queued CI must qualify the native platform'
        summary['priorEvidenceArchive'] = ARCHIVE
        summary['semanticParityEvidence'] = {'unchangedBinariesAndFixtures': True,
                                            'sha256': original_summary['semanticSHA256']}
        summary['inputHashesUnchanged'] = True
        summary['freshProcessCount'] = len(samples)
        summary['limitations'] += ['Adapted Linux Foundation imports, no-op autoreleasepool shim, and glibc heap probe; not native macOS.',
                                  'Shared-host wall-clock timing is descriptive and is not a performance guarantee.',
                                  'Functional qualification is the pure PlexMatch regression suite only; native reader/sidecar test suites remain separate.']
        if not summary['largeCaseMemoryReductionObserved']:
            summary['status'] = 'no-demonstrated-memory-reduction'
        save('summary.json', summary)
        print(json.dumps({'status': summary['status'], 'freshProcessCount': len(samples),
                          'inputHashesUnchanged': True,
                          'largeCaseMemoryReductionObserved': summary['largeCaseMemoryReductionObserved']}), flush=True)
    except Exception as error:
        save('failure.json', {'type': type(error).__name__, 'error': str(error)})
        raise


if __name__ == '__main__':
    main()
