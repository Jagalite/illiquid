#!/usr/bin/env python3
"""Read-only verification and statistical recomputation of completed receipts."""
from pathlib import Path
import collections,datetime,gzip,hashlib,json,math,re,statistics,subprocess,tarfile

ROOT=Path('/workspace/scratch/8fcd5918c010/illiquid')
EV=Path('/tmp/illiquid-row-storage-final-linux-measurements/evidence')
OUT=Path('/tmp/illiquid-row-storage-independent-audit.json')
REV='914b87e4a587676b6d9e97aab0d4b8d26f4fd244'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda name:json.loads((EV/name).read_text())

def check(condition,message):
    if not condition:raise AssertionError(message)

def stats(baseline,candidate):
    ratios=[c/b for b,c in zip(baseline,candidate)] if all(b>0 for b in baseline) else []
    return {
      'baseline_median':statistics.median(baseline),'candidate_median':statistics.median(candidate),
      'baseline_range':[min(baseline),max(baseline)],'candidate_range':[min(candidate),max(candidate)],
      'median_paired_change':statistics.median(c-b for b,c in zip(baseline,candidate)),
      'paired_changes':[c-b for b,c in zip(baseline,candidate)],
      'median_paired_increase_percent':100*(statistics.median(ratios)-1) if ratios else None,
      'paired_increase_percent_range':[100*(min(ratios)-1),100*(max(ratios)-1)] if ratios else None,
      'positive_change_pairs':sum(c>b for b,c in zip(baseline,candidate)),
      'nonoverlapping_ranges_candidate_above':min(candidate)>max(baseline),
    }

def main():
    completion=read('continuation-completion.json')
    check(completion['passed'] and completion['observations']==432 and completion['paired_output_checks']==216,'Incomplete continuation')
    check(completion['source_and_binary_hashes_verified_before_and_after'],'Source verification incomplete')
    environment=read('continuation-environment.json')
    check(environment['validated_candidate_head']==REV,'Wrong source revision')
    check(str(environment['pid_namespace']['pid'])==environment['pid_namespace']['proc_self'],'PID namespace mismatch')
    check(environment['pairs']==6 and environment['iterations_per_process']==1,'Unexpected measurement configuration')
    prior=EV/'validated-correctness'
    original_hashes=environment['original_correctness_evidence_sha256']
    for path,expected in original_hashes.items():check(sha((prior/path).read_bytes())==expected,'Copied correctness artifact mismatch '+path)
    original_sources=environment['original_source_hashes']
    tests=json.loads((prior/'tests.json').read_text())
    check([(r.get('variant'),r.get('configuration'),r.get('reported_tests')) for r in tests['runs'] if r.get('passed')]==[('baseline','release',44),('candidate','debug',47),('candidate','release',47)],'Correctness test receipt mismatch')
    failure=(prior/'expected-baseline-storage-failure.log').read_text()
    issues=[line for line in failure.splitlines() if 'recorded an issue' in line]
    check(len(issues)==7 and all('RowStorageFixture.sharesStorage' in line for line in issues),'Unexpected baseline test failures')
    for path,expected in original_sources.items():
        check(sha(subprocess.check_output(['git','-C',str(ROOT),'show',REV+':'+path]))==expected,'Source commit mismatch '+path)
        check(sha((ROOT/path).read_bytes())==expected,'Current source mismatch '+path)
    manifests={v:json.loads((prior/(v+'-sources.json')).read_text()) for v in ['baseline','candidate']}
    prior_commands=[json.loads(line) for line in (prior/'commands.jsonl').read_text().splitlines()]
    for v,manifest in manifests.items():
        loc=[r['stdout'].strip() for r in prior_commands if r['label']=='binary-path-'+v]
        check(len(loc)==1,'Ambiguous binary path')
        binary=Path(loc[0])/'SourceBrowserRowStorageBenchmark'
        check(sha(binary.read_bytes())==manifest['binary_sha256']==environment['binary_sha256'][v],'Binary mismatch '+v)
    with tarfile.open(EV/'staged-sources.tar.gz') as archive:
        staged={m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
    for v,manifest in manifests.items():
        for path,record in manifest['staged'].items():check(sha(staged[v+'/'+path])==record['compiled_sha256'],'Staged source mismatch '+v+'/'+path)
    for path,raw in staged.items():
        if path.startswith('drivers/'):
            check(sha(raw)==original_sources[path.removeprefix('drivers/')],'Archived driver mismatch '+path)
    for path in manifests['candidate']['staged']:
        check((staged['baseline/'+path]!=staged['candidate/'+path])==(path=='Sources/IlliquidApp/SourceBrowserFilter.swift'),'Unexpected comparison difference '+path)
    check(sha((EV/'continuation.py').read_bytes())==environment['continuation_driver_sha256'],'Continuation driver mismatch')
    parity=json.loads((prior/'parity.json').read_text())['cases']
    for case in parity:
        raw=gzip.decompress((prior/f'semantic-output/{case["case"]}.json.gz').read_bytes())
        check(sha(raw)==case['sha256'] and len(raw)==case['byte_count'],'Complete semantic artifact mismatch')
        checksum=14695981039346656037
        for b in raw:checksum=((checksum^b)*1099511628211)&((1<<64)-1)
        check(str(checksum)==case['checks']['semantic_fnv1a64'],'Semantic fingerprint mismatch')
    check(len(parity)==17,'Missing complete semantic controls')
    records=[json.loads(line) for line in (EV/'observations.jsonl').read_text().splitlines()]
    commands=[json.loads(line) for line in (EV/'commands.jsonl').read_text().splitlines()]
    check(len(records)==432 and len(commands)==432,'Missing or extra measurement records')
    groups=collections.defaultdict(list)
    expected_order=[]
    for size in environment['sizes']:
        for case in environment['cases']:
            for pair in range(6):
                order=['baseline','candidate'] if pair%2==0 else ['candidate','baseline']
                for position,variant in enumerate(order):expected_order.append((case,size,pair,variant,position))
    order_counts=collections.Counter()
    shared_expected={'tree','files','folders','no_match','cache_hit'}
    for r,command,expected in zip(records,commands,expected_order):
        actual=(r['scenario'],r['count'],r['pair'],r['variant'],r['process_order'])
        check(actual==expected,'Observation sequence/order mismatch')
        case,size,pair,variant,position=actual
        check(command['returncode']==0,'Failed measurement command')
        check(command['label']==f'measure-{variant}-{case}-{size}-{pair}','Command label mismatch')
        observed=json.loads(command['stdout'])
        check(observed=={k:v for k,v in r.items() if k not in {'variant','pair','process_order'}},'Raw command output mismatch')
        check(r['iterations']==1 and r['schema']==1 and r['mode']=='measure','Invalid observation')
        check(r['loop_cpu_nanoseconds']>0 and r['loop_wall_nanoseconds']>0,'Missing timing')
        check(r['row_stride_bytes']==320,'Unexpected row stride')
        check(r['tree_build_count']==0 and r['visibility_build_count']==1,'Unexpected code path')
        for kind in ['fixture','projection']:
            check(r[f'retained_{kind}_delta_bytes']==r['allocator_after_projection_bytes']-r[f'allocator_before_{kind}_bytes'],'Allocator arithmetic mismatch')
        check(r['shares_input_storage']==(variant=='candidate' and case in shared_expected),'Unexpected storage sharing')
        if position==0:order_counts['AB' if variant=='baseline' else 'BA']+=1
        groups[(size,case)].append(r)
    check(order_counts=={'AB':108,'BA':108},'Unbalanced order')
    published={(r['count'],r['case']):r for r in read('summary.json')}
    check(len(groups)==len(published)==36,'Incomplete matrix')
    metrics=['retained_fixture_delta_bytes','retained_projection_delta_bytes','loop_wall_nanoseconds','loop_cpu_nanoseconds','output_row_capacity']
    audited=[]
    for (size,case),group in groups.items():
        by_variant={v:sorted([r for r in group if r['variant']==v],key=lambda r:r['pair']) for v in ['baseline','candidate']}
        check(all(len(v)==6 and [r['pair'] for r in v]==list(range(6)) for v in by_variant.values()),'Missing paired members')
        checks=group[0]['checks']
        check(all(r['checks']==checks for r in group),'Semantic measured receipts mismatch')
        computed={m:stats([r[m] for r in by_variant['baseline']],[r[m] for r in by_variant['candidate']]) for m in metrics}
        p=published[(size,case)]
        for m,s in computed.items():
            for key in ['baseline_median','candidate_median','baseline_range','candidate_range','median_paired_change']:
                check(s[key]==p['metrics'][m][key],'Published statistic mismatch '+str((size,case,m,key)))
            reduction=p['metrics'][m]['median_paired_reduction_percent'];increase=s['median_paired_increase_percent']
            check((reduction is None and increase is None) or math.isclose(reduction,-increase,rel_tol=1e-10,abs_tol=1e-10),'Published paired ratio mismatch')
        audited.append({'count':size,'case':case,'pairs':6,'metrics':computed,'checks':checks,
                        'shared_input_storage_observations':{v:sum(r['shares_input_storage'] for r in rows) for v,rows in by_variant.items()}})
    regressions=[]
    for group in audited:
        for metric in ['loop_cpu_nanoseconds','loop_wall_nanoseconds']:
            result=group['metrics'][metric]
            if result['median_paired_increase_percent']>0:
                regressions.append({'case':group['case'],'count':group['count'],'metric':metric,**result})
    limits=[
      'Linux x86-64 Swift 6.3.2 component evidence; no native macOS qualification result is asserted.',
      'Live allocator-accounted bytes while fixture, actor cache and returned projection remain alive; not process RSS, peak memory, whole-player RAM or exact per-object allocation bytes.',
      'Fixture delta includes input construction; projection delta excludes inputs. Cache-hit projection delta measures an already-primed hit, while fixture delta includes the primed cache.',
      'rows: API overload only; tree_build_count=0 in every observation. No directory discovery, tree construction, UI rendering, video decoding, or real-library GUI responsiveness was timed.',
      'Complete byte comparisons cover 17 deterministic cases at 257 rows. Larger measured cases agree on full-output fingerprints and semantic counts; those 432 observations did not retain two complete byte outputs each.',
      'Six alternating AB/BA fresh-process pairs per case and size. All observations retained without retry or trimming; min/max ranges describe this sample, not confidence intervals.',
      'Timing from a busy shared host is descriptive; positive paired differences are reported, and no generalized speedup or no-regression guarantee is inferred.',
      'Only unannotated unchanged rows share storage. Existing nonnil annotations are refreshed to preserve configured Unicode bytes even when Swift String equality considers IDs equivalent.',
    ]
    artifact_names=['observations.jsonl','commands.jsonl','summary.json','completion.json','continuation-environment.json','continuation-completion.json','continuation.py','staged-sources.tar.gz','host.json']
    report={'schema':1,'audited_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':REV,'passed':True,'native_qualification':{'url':'https://github.com/Jagalite/illiquid/actions/runs/40104705034','status':'Pending; no native result was evaluated by this audit.','workflow_head_reported_by_root':'fe8cb7388bf65746cee3a1ce01ff65839aaac78a'},
      'verification':{'source_inputs':len(original_sources),'staged_source_files':sum(len(m['staged']) for m in manifests.values()),'archived_driver_files':sum(path.startswith('drivers/') for path in staged),'staged_archive_total_files':len(staged),'production_files_per_variant':14,'shared_production_files':13,'binary_hashes':environment['binary_sha256'],
        'correctness_artifact_files':len(original_hashes),'complete_semantic_cases':len(parity),'candidate_tests_debug':47,'candidate_tests_release':47,'baseline_semantic_tests':44,
        'baseline_storage_tests_expected_failed':3,'baseline_storage_sharing_assertions_expected_failed':7,'observations':len(records),'paired_comparisons':len(records)//2,'groups':len(groups),
        'order_counts':dict(order_counts),'source_and_binary_match':True,'observations_match_command_stdout':True,'all_summary_statistics_match_independent_recomputation':True,
        'pid_namespace':environment['pid_namespace'],'no_unexpected_command_failures':True},
      'input_sha256':{name:sha((EV/name).read_bytes()) for name in artifact_names},
      'host':read('host.json'),'all_groups':audited,'full_100k_table':[g for g in audited if g['count']==100000],
      'observed_positive_paired_timing_changes':regressions,'limitations':limits}
    OUT.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    md=['# Independent row-storage evidence audit','',f'Source: `{REV}`. Linux component evidence only. All 432 observations / 216 paired comparisons passed the audit; 108 AB and 108 BA pairs. No native result is asserted.','',
        '## Retained allocator deltas at 100,000 rows','',
        '| Workload | Projection baseline B | Projection candidate B | Paired reduction | Fixture baseline B | Fixture candidate B | Candidate shares input |',
        '|---|---:|---:|---:|---:|---:|:---:|']
    for g in report['full_100k_table']:
        p=g['metrics']['retained_projection_delta_bytes'];f=g['metrics']['retained_fixture_delta_bytes'];change=p['median_paired_increase_percent']
        reduction='n/a' if change is None else ('0.00%' if change == 0 else (f'{-change:.4f}%' if -change > 99.995 else f'{-change:.2f}%'))
        md.append(f'| {g["case"]} | {p["baseline_median"]:,.0f} | {p["candidate_median"]:,.0f} | {reduction} | {f["baseline_median"]:,.0f} | {f["candidate_median"]:,.0f} | {g["shared_input_storage_observations"]["candidate"]}/6 |')
    md += ['', '## Timing at 100,000 rows', '', 'Positive paired changes mean the candidate took longer. Times and ranges are milliseconds; paired changes are medians of per-pair ratios, not ratios of medians.', '',
           '| Workload | CPU baseline median [min,max] | CPU candidate median [min,max] | Paired CPU change | Wall baseline median [min,max] | Wall candidate median [min,max] | Paired wall change |',
           '|---|---:|---:|---:|---:|---:|---:|']
    def timed(s,variant):
        lo,hi=s[variant+'_range'];return f'{s[variant+"_median"]/1e6:.3f} [{lo/1e6:.3f}, {hi/1e6:.3f}]'
    for g in report['full_100k_table']:
        c=g['metrics']['loop_cpu_nanoseconds'];w=g['metrics']['loop_wall_nanoseconds']
        md.append(f'| {g["case"]} | {timed(c,"baseline")} | {timed(c,"candidate")} | {c["median_paired_increase_percent"]:+.2f}% | {timed(w,"baseline")} | {timed(w,"candidate")} | {w["median_paired_increase_percent"]:+.2f}% |')
    md += ['', '## Observed paired timing increases of at least 5%', '', '| Rows | Workload | Metric | Baseline median ms | Candidate median ms | Paired increase | Candidate slower pairs |', '|---:|---|---|---:|---:|---:|---:|']
    for r in regressions:
        if r['median_paired_increase_percent']>=5:
            md.append(f'| {r["count"]:,} | {r["case"]} | {"CPU" if "cpu" in r["metric"] else "Wall"} | {r["baseline_median"]/1e6:.3f} | {r["candidate_median"]/1e6:.3f} | {r["median_paired_increase_percent"]:+.2f}% | {r["positive_change_pairs"]}/6 |')
    md += ['', '## Limits', '']+['- '+s for s in limits]
    OUT.with_suffix('.md').write_text('\n'.join(md)+'\n')
    print(json.dumps(report['verification'],indent=2))
    print('\n'.join(md))

if __name__=='__main__':main()
