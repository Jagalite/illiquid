#!/usr/bin/env python3
"""Measure the exact binaries from an already completed correctness run.

No builds, tests, production edits, or benchmark implementation replacements occur.
The original run and evidence are read-only. Use --check-only for review/preflight.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import time
import types


REPOSITORY = Path('/workspace/scratch/8fcd5918c010/illiquid')
RUNNER_RELATIVE = 'Benchmarks/SourceBrowserRowStorage/run.py'


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text())


def file_hashes(root: Path) -> dict[str, str]:
    return {str(path.relative_to(root)): digest(path)
            for path in sorted(root.rglob('*')) if path.is_file()}


def check_hashes(root: Path, hashes: dict[str, str]) -> None:
    if file_hashes(root) != hashes:
        raise RuntimeError(f'Evidence files changed: {root}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--validated', type=Path,
                        default=Path('/tmp/illiquid-row-storage-final-linux-correctness'))
    parser.add_argument('--output', type=Path,
                        default=Path('/tmp/illiquid-row-storage-final-linux-measurements'))
    parser.add_argument('--check-only', action='store_true')
    options = parser.parse_args()
    prior, output = options.validated.resolve(), options.output.resolve()
    if output == prior or output.is_relative_to(prior) or prior.is_relative_to(output):
        raise RuntimeError('The continuation output must be separate from the validated run')
    if platform.system() != 'Linux' or os.readlink('/proc/self') != str(os.getpid()):
        raise RuntimeError('This continuation requires a clean, consistent Linux PID namespace')
    environment = read_json(prior / 'environment.json')
    completion = read_json(prior / 'completion.json')
    tests = read_json(prior / 'tests.json')
    parity = read_json(prior / 'parity.json')
    if not (completion.get('passed') and completion.get('tests_only')
            and completion.get('source_and_binary_hashes_rechecked')
            and completion.get('complete_output_comparisons') == 17
            and environment.get('tests_only') and not environment.get('skip_tests')
            and not environment.get('exploratory')):
        raise RuntimeError('The prior correctness run is incomplete or exploratory')
    passed = [(run.get('variant'), run.get('configuration'), run.get('reported_tests'))
              for run in tests['runs'] if run.get('passed')]
    if passed != [('baseline', 'release', 44), ('candidate', 'debug', 47), ('candidate', 'release', 47)]:
        raise RuntimeError(f'Unexpected final correctness receipts: {passed}')
    if not any(run.get('expected_storage_regression') for run in tests['runs']):
        raise RuntimeError('The expected baseline storage-regression proof is absent')
    if len(parity['cases']) != 17 or not all(case.get('complete_bytes_equal') for case in parity['cases']):
        raise RuntimeError('The complete-output parity receipts are incomplete')

    originals = {}
    for relative, expected in environment['original_source_hashes'].items():
        raw = (REPOSITORY / relative).read_bytes()
        if hashlib.sha256(raw).hexdigest() != expected:
            raise RuntimeError(f'Current source differs from the validated run: {relative}')
        originals[relative] = raw
    if RUNNER_RELATIVE not in originals:
        raise RuntimeError('The prior run did not record its runner source hash')
    # Execute the validated bytes directly, avoiding a stale Python bytecode cache.
    runner_source = REPOSITORY / RUNNER_RELATIVE
    study = types.ModuleType('validated_source_browser_row_storage')
    study.__file__ = str(runner_source)
    exec(compile(originals[RUNNER_RELATIVE], str(runner_source), 'exec'), study.__dict__)
    manifests = {variant: read_json(prior / f'{variant}-sources.json')
                 for variant in ['baseline', 'candidate']}
    packages = {variant: prior / 'packages' / variant for variant in manifests}
    commands = [json.loads(line) for line in (prior / 'commands.jsonl').read_text().splitlines()]
    binaries = {}
    for variant, manifest in manifests.items():
        for relative, record in manifest['staged'].items():
            if digest(packages[variant] / relative) != record['compiled_sha256']:
                raise RuntimeError(f'Validated staged input changed: {variant}/{relative}')
        locations = [record['stdout'].strip() for record in commands
                     if record['label'] == f'binary-path-{variant}' and record['returncode'] == 0]
        if len(locations) != 1:
            raise RuntimeError(f'Expected one recorded binary directory for {variant}')
        binary = (Path(locations[0]) / 'SourceBrowserRowStorageBenchmark').resolve()
        if not binary.is_relative_to(prior) or digest(binary) != manifest['binary_sha256']:
            raise RuntimeError(f'Validated binary changed or escaped its run directory: {variant}')
        binaries[variant] = binary
    receipt_hashes = file_hashes(prior / 'evidence')
    for name in ['environment.json', 'completion.json', 'tests.json', 'parity.json',
                 'baseline-sources.json', 'candidate-sources.json', 'commands.jsonl']:
        if digest(prior / name) != receipt_hashes.get(name):
            raise RuntimeError(f'Original and exported correctness receipts disagree: {name}')
    compiler = subprocess.check_output(['swift', '--version'], text=True).strip()
    if compiler != environment['compiler']:
        raise RuntimeError('The current Swift toolchain differs from the correctness run')
    if len(study.DEFAULT_CASES) != 12:
        raise RuntimeError('The reviewed twelve-scenario measurement matrix changed')
    driver = Path(__file__).resolve()
    driver_hash = digest(driver)
    specification = {
        'validated_run': str(prior), 'output': str(output),
        'validated_candidate_head': environment['candidate_head'],
        'current_checkout_head': subprocess.check_output(['git', '-C', str(REPOSITORY), 'rev-parse', 'HEAD'], text=True).strip(),
        'pid_namespace': {'pid': os.getpid(), 'proc_self': os.readlink('/proc/self')},
        'compiler': compiler, 'platform': platform.platform(), 'machine': platform.machine(),
        'cases': list(study.DEFAULT_CASES), 'sizes': [1_000, 10_000, 100_000],
        'pairs': 6, 'iterations_per_process': 1, 'expected_observations': 432,
        'expected_pairs': 216, 'fresh_process_per_observation': True,
        'ordering': 'Existing Runner.measure alternating AB/BA order',
        'method': 'Existing validated Runner.measure/observe/check_sources, with exact validated staged packages and executable files; no builds or tests rerun',
        'scope': 'Portable component retained-allocation corroboration; native macOS qualification remains separate and required for ready status',
        'original_source_hashes': environment['original_source_hashes'],
        'binary_sha256': {variant: manifests[variant]['binary_sha256'] for variant in manifests},
        'original_correctness_evidence_sha256': receipt_hashes,
        'continuation_driver_sha256': driver_hash,
        'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    if options.check_only:
        print(json.dumps({key: specification[key] for key in [
            'validated_candidate_head', 'pid_namespace', 'cases', 'sizes', 'pairs',
            'expected_observations', 'method', 'continuation_driver_sha256']}, indent=2))
        return

    args = argparse.Namespace(output=output, swift=shutil.which('swift'), pairs=6,
                              sizes=specification['sizes'], cases=specification['cases'],
                              iterations=1, jobs=2, tests_only=False, skip_tests=False,
                              prove_baseline_failure=False, smoke=False)
    runner = study.Runner(args)
    runner.originals, runner.manifests = originals, manifests
    runner.packages, runner.binaries = packages, binaries
    copied = output / 'validated-correctness'
    shutil.copytree(prior / 'evidence', copied)
    check_hashes(copied, receipt_hashes)
    shutil.copyfile(driver, output / 'continuation.py')
    study.save(output / 'continuation-environment.json', specification)
    try:
        runner.check_sources()
        runner.measure()
        runner.check_sources()
        if digest(driver) != driver_hash or digest(output / 'continuation.py') != driver_hash:
            raise RuntimeError('Continuation driver changed during measurement')
        check_hashes(prior / 'evidence', receipt_hashes)
        check_hashes(copied, receipt_hashes)
        result = read_json(output / 'completion.json')
        if not (result.get('passed') and result.get('observations') == 432
                and result.get('paired_output_checks') == 216):
            raise RuntimeError('The expected measurement matrix did not complete')
        study.save(output / 'continuation-completion.json', {
            'passed': True, 'source_and_binary_hashes_verified_before_and_after': True,
            'original_correctness_evidence_unchanged': True,
            'copied_correctness_evidence_byte_identical': True,
            'observations': 432, 'paired_output_checks': 216,
            'finished_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        })
    finally:
        # The existing exporter writes into the fresh continuation output only.
        runner.export_evidence()
        shutil.copytree(copied, output / 'evidence' / 'validated-correctness')
        shutil.copyfile(driver, output / 'evidence' / 'continuation.py')


if __name__ == '__main__':
    main()
