import Foundation

public struct PlaybackSessionRecord: Codable, Equatable, Sendable {
    public static let currentSchemaVersion = 2

    public let schemaVersion: Int
    public var source: MediaSource
    public var collectionFolder: URL?
    public var playlistItems: [FolderPlaylistItem]
    public var playlistIndex: Int?
    public var unshuffledPlaylistIDs: [FolderPlaylistItem.ID]?
    public var position: TimeInterval
    public var wasPaused: Bool
    public var updatedAt: Date

    public init(
        source: MediaSource,
        collectionFolder: URL? = nil,
        playlistItems: [FolderPlaylistItem] = [],
        playlistIndex: Int? = nil,
        position: TimeInterval,
        wasPaused: Bool,
        unshuffledPlaylistIDs: [FolderPlaylistItem.ID]? = nil,
        updatedAt: Date = Date()
    ) {
        schemaVersion = Self.currentSchemaVersion
        self.source = source
        self.collectionFolder = collectionFolder
        self.playlistItems = PlaylistMutation.deduplicated(playlistItems)
        self.playlistIndex = playlistIndex
        self.unshuffledPlaylistIDs = unshuffledPlaylistIDs
        self.position = max(0, position.isFinite ? position : 0)
        self.wasPaused = wasPaused
        self.updatedAt = updatedAt
    }

    private enum CodingKeys: String, CodingKey {
        case schemaVersion
        case source
        case collectionFolder
        case playlistItems
        case playlistIndex
        case unshuffledPlaylistIDs
        case position
        case wasPaused
        case updatedAt
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        schemaVersion = try container.decodeIfPresent(
            Int.self,
            forKey: .schemaVersion
        ) ?? 1
        source = try container.decode(MediaSource.self, forKey: .source)
        collectionFolder = try container.decodeIfPresent(
            URL.self,
            forKey: .collectionFolder
        )
        playlistItems = PlaylistMutation.deduplicated(
            try container.decodeIfPresent(
                [FolderPlaylistItem].self,
                forKey: .playlistItems
            ) ?? []
        )
        playlistIndex = try container.decodeIfPresent(Int.self, forKey: .playlistIndex)
        unshuffledPlaylistIDs = try container.decodeIfPresent(
            [FolderPlaylistItem.ID].self, forKey: .unshuffledPlaylistIDs
        )
        let decodedPosition = try container.decodeIfPresent(
            TimeInterval.self,
            forKey: .position
        ) ?? 0
        position = max(0, decodedPosition.isFinite ? decodedPosition : 0)
        wasPaused = try container.decodeIfPresent(Bool.self, forKey: .wasPaused) ?? false
        updatedAt = try container.decodeIfPresent(Date.self, forKey: .updatedAt) ?? .distantPast
    }
}

